#!/usr/bin/env python3
"""
Version-2-Only Paper Tables Generator & Statistical Reconciler (Version 2.0.3)
Project: mcp-inventory-bench / Version 2.0.3
Author: Anand S. Suchak

Generates LaTeX tables I, II, III, and IV strictly into:
version_2/paper_v2/tables/
NEVER writes to protected root paper/tables/!

Recomputes paired outcomes by joining strictly on task_id.
"""

import sys
import os
import json
import math
import random
import statistics
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Dict, Any, List, Tuple

WORKSPACE = Path(__file__).resolve().parent.parent
if str(WORKSPACE) not in sys.path:
    sys.path.insert(0, str(WORKSPACE))
TABLES_DIR = WORKSPACE / "version_2" / "paper_v2" / "tables"

def round_half_up(val: float, decimals: int = 1) -> str:
    d = Decimal(str(val))
    fmt = "0." + "0" * decimals if decimals > 0 else "0"
    return str(d.quantize(Decimal(fmt), rounding=ROUND_HALF_UP))

def generate_table1(frozen_data: Dict[str, Any]) -> str:
    sb = frozen_data["systems_benchmark"]
    arms = [
        ("Full Schema Control", "full", "No", 552.0, 0.0),
        (r"$C_I^*$ Baseline ($k=0$)", "ci_k0", "No", 339.0, 0.0),
        (r"LASR $k=1$ (Static)", "ci_k1_static", "No", 361.1, 0.0),
        (r"LASR $k=1$ (Reactive)", "ci_k1_reactive", "Yes", 361.1, 45.4),
        (r"LASR $k=2$ (Reactive)", "ci_k2_reactive", "Yes", 366.8, 43.8),
        (r"Oracle $O(x)$ (Reactive)*", "oracle_reactive", "Yes", 359.0, 48.3)
    ]

    rows = []
    for label, arm_key, reactive, init_s0, exp_s in arms:
        arm = sb[arm_key]
        fp_pct = round_half_up(arm["first_pass_structural_pct"], 1)
        st_pct = round_half_up(arm["final_structural_pct"], 1)
        sem_pct = round_half_up(arm["final_semantic_correctness_pct"], 1)
        mean_tts = f"{arm['mean_tts']:.1f}"
        tot_tok = f"{arm['total_tokens_consumed']:,}"

        # Bold highlight top systems
        if arm_key in ["ci_k1_reactive", "ci_k2_reactive"]:
            st_str = f"\\textbf{{{st_pct}\\%}}"
        elif arm_key == "full":
            st_str = f"\\textbf{{{st_pct}\\%}}"
        else:
            st_str = f"{st_pct}\\%"

        if arm_key == "ci_k2_reactive":
            tok_str = f"\\textbf{{{tot_tok}}}"
        elif arm_key == "full":
            tok_str = f"\\textbf{{{tot_tok}}}"
        else:
            tok_str = tot_tok

        rows.append(
            f"{label} & {reactive} & {init_s0:.1f} & {exp_s:.1f} & {fp_pct}\\% & "
            f"{st_str} & {sem_pct}\\% & {mean_tts} & {tok_str} \\\\"
        )

    rows_tex = "\n".join(rows)
    content = f"""\\begin{{table*}}[t]
\\centering
\\caption{{Full-Spectrum Systems Evaluation across 32 Development/Validation Tasks ($N=32$, Gemini 3.5 Flash-Lite)}}
\\label{{tab:systems_evaluation}}
\\resizebox{{\\textwidth}}{{!}}{{%
\\begin{{tabular}}{{lcccccccc}}
\\toprule
\\textbf{{System Arm}} & \\textbf{{Reactive?}} & \\textbf{{Init $S_0$}} & \\textbf{{Exp. $\\Delta S$}} & \\textbf{{1st-Pass (\\%)}} & \\textbf{{Struct. (\\%)}} & \\textbf{{Sem. (\\%)}} & \\textbf{{Mean $TTS$}} & \\textbf{{Total Tokens}} \\\\
\\midrule
{rows_tex}
\\bottomrule
\\end{{tabular}}%
}}
\\vspace{{1mm}}
\\begin{{minipage}}{{\\textwidth}}
\\footnotesize
*\\textit{{Note}}: Oracle $O(x)$ is a model-conditional reference baseline. First-pass success for Full Schema is 10/32 tasks (31.25\\%, displayed 31.3\\%). Mean $TTS$ is averaged over successful trajectories ($N_{{\\text{{succ}}}}$); Total Tokens accounts for all attempts across all 32 tasks.
\\end{{minipage}}
\\end{{table*}}
"""
    return content

def generate_table2(frozen_data: Dict[str, Any]) -> str:
    sb = frozen_data["systems_benchmark"]
    full_recs = {r["task_id"]: r for r in sb["full"]["records"]}
    static_recs = {r["task_id"]: r for r in sb["ci_k1_static"]["records"]}
    k1_recs = {r["task_id"]: r for r in sb["ci_k1_reactive"]["records"]}
    k2_recs = {r["task_id"]: r for r in sb["ci_k2_reactive"]["records"]}

    # 1. Reactive k=1 vs Static k=1
    st_diffs_static = []
    sem_diffs_static = []
    for tid in sorted(k1_recs.keys()):
        st_diffs_static.append(int(k1_recs[tid]["final_structural_success"]) - int(static_recs[tid]["final_structural_success"]))
        sem_diffs_static.append(int(k1_recs[tid]["final_semantic_correctness"]) - int(static_recs[tid]["final_semantic_correctness"]))

    # 2. Reactive k=1 vs Full
    st_diffs_full = []
    sem_diffs_full = []
    for tid in sorted(k1_recs.keys()):
        st_diffs_full.append(int(k1_recs[tid]["final_structural_success"]) - int(full_recs[tid]["final_structural_success"]))
        sem_diffs_full.append(int(k1_recs[tid]["final_semantic_correctness"]) - int(full_recs[tid]["final_semantic_correctness"]))

    # Bootstrap 95% CI helper
    random.seed(42)
    def calc_ci(diff_list):
        B = 10000
        n = len(diff_list)
        means = []
        for _ in range(B):
            sample = [random.choice(diff_list) for _ in range(n)]
            means.append(statistics.mean(sample) * 100.0)
        means.sort()
        return round_half_up(means[int(0.025 * B)], 1), round_half_up(means[int(0.975 * B)], 1)

    ci_st_static = calc_ci(st_diffs_static)
    ci_sem_static = calc_ci(sem_diffs_static)
    ci_st_full = calc_ci(st_diffs_full)
    ci_sem_full = calc_ci(sem_diffs_full)

    content = f"""\\begin{{table}}[htbp]
\\centering
\\caption{{Paired Confidence Intervals and Hypothesis Tests ($N=32$ Development/Validation Tasks)}}
\\label{{tab:paired_bootstrap}}
\\resizebox{{\\columnwidth}}{{!}}{{%
\\begin{{tabular}}{{lcccc}}
\\toprule
\\textbf{{Pairwise Contrast}} & \\textbf{{Metric}} & \\textbf{{Point Est.}} & \\textbf{{95\\% Bootstrap CI}} & \\textbf{{Significance Test ($p$)}} \\\\
\\midrule
LASR Reactive vs Static ($k=1$) & $\\Delta$ Structural Succ. & \\textbf{{+21.9 pp}} & [{ci_st_static[0]}, {ci_st_static[1]}] pp & Exact one-sided McNemar/binomial ($p = 0.0078125$) \\\\
& $\\Delta$ Semantic Corr. & \\textbf{{+21.9 pp}} & [{ci_sem_static[0]}, {ci_sem_static[1]}] pp & Exact one-sided McNemar/binomial ($p = 0.0078125$) \\\\
\\midrule
LASR Reactive ($k=1$) vs Full & $\\Delta$ Structural Succ. & +6.2 pp & [{ci_st_full[0]}, {ci_st_full[1]}] pp & Exact one-sided McNemar/binomial ($p = 0.250$) \\\\
& $\\Delta$ Semantic Corr. & +3.1 pp & [{ci_sem_full[0]}, {ci_sem_full[1]}] pp & Exact one-sided McNemar/binomial ($p = 0.500$) \\\\
\\midrule
LASR Reactive ($k=1$) vs Full & Total Workload Tokens & \\textbf{{-20.2\\%}} & -19,489 tokens & Paired Empirical Workload \\\\
LASR Reactive ($k=2$) vs Full & Total Workload Tokens & \\textbf{{-22.1\\%}} & -21,381 tokens & Paired Empirical Workload \\\\
\\bottomrule
\\end{{tabular}}%
}}
\\end{{table}}
"""
    return content

def generate_table3(frozen_data: Dict[str, Any]) -> str:
    sb = frozen_data["systems_benchmark"]
    full_recs = sb["full"]["records"]
    static_recs = sb["ci_k1_static"]["records"]
    k1_recs = sb["ci_k1_reactive"]["records"]

    clusters = [
        ("C1: Routine Regional", "routine_regional_replenish"),
        ("C2: Expedited Emergency", "expedited_emergency_order"),
        ("C3: Specialized Bulk", "specialized_bulk_procurement"),
        ("C4: Multi-Item Depot", "multi_item_depot_rebalance")
    ]

    rows = []
    for label, ckey in clusters:
        f_sub = [r for r in full_recs if r["cluster"] == ckey]
        s_sub = [r for r in static_recs if r["cluster"] == ckey]
        k_sub = [r for r in k1_recs if r["cluster"] == ckey]

        f_pct = sum(1 for r in f_sub if r["final_structural_success"]) / len(f_sub) * 100.0
        s_pct = sum(1 for r in s_sub if r["final_structural_success"]) / len(s_sub) * 100.0
        k_pct = sum(1 for r in k_sub if r["final_structural_success"]) / len(k_sub) * 100.0
        lift = k_pct - s_pct

        lift_str = f"\\textbf{{+{lift:.1f} pp}}" if lift > 0 else f"\\textbf{{{lift:.1f} pp}}"
        rows.append(
            f"{label} & {f_pct:.1f}\\% & {s_pct:.1f}\\% & \\textbf{{{k_pct:.1f}\\%}} & {lift_str} \\\\"
        )

    rows_tex = "\n".join(rows)
    content = f"""\\begin{{table}}[htbp]
\\centering
\\caption{{Task Archetype Breakdown: Static Vulnerability vs. Reactive Recovery ($N=8$ per Cluster)}}
\\label{{tab:cluster_breakdown}}
\\resizebox{{\\columnwidth}}{{!}}{{%
\\begin{{tabular}}{{lcccc}}
\\toprule
\\textbf{{Task Cluster Archetype}} & \\textbf{{Full (\\%)}} & \\textbf{{Static $k=1$}} & \\textbf{{Reactive $k=1$}} & \\textbf{{Observed Lift}} \\\\
\\midrule
{rows_tex}
\\bottomrule
\\end{{tabular}}%
}}
\\end{{table}}
"""
    return content

def generate_table4(cross_summary: Dict[str, Any]) -> str:
    schemas = [
        ("create_purchase_order", r"\texttt{create\_purchase\_order}"),
        ("inventory_adjustment", r"\texttt{inventory\_adjustment}"),
        ("shipment_creation", r"\texttt{shipment\_creation}"),
        ("customer_refund", r"\texttt{customer\_refund}")
    ]

    rows = []
    for skey, slabel in schemas:
        sdata = cross_summary["per_schema"][skey]
        floor = sdata["invariant_floor_c_i"]
        mean_s0 = int(round(sdata["mean_initial_s0"]))
        full_s = sdata["full_schema_s"]
        sav = round_half_up(sdata["exact_savings_pct"], 1)
        fp = f"{sdata['first_pass_pct']:.1f}\\% ({sdata['first_pass_breakdown']})"
        st = f"\\textbf{{{sdata['final_struct_pct']:.1f}\\%}}"
        sem = f"{sdata['semantic_pct']:.1f}\\%"
        amb = f"\\textbf{{{sdata['ambiguous_recovery_pct']:.1f}\\%}} ({sdata['ambiguous_recovered_count']})"

        rows.append(
            f"{slabel} & {sdata['domain_description']} & {floor} & {mean_s0} & {full_s} & "
            f"\\textbf{{{sav}\\%}} & {fp} & {st} & {sem} & {amb} \\\\"
        )

    macro = cross_summary["unweighted_macro_mean"]
    pooled = cross_summary["pooled_workload_aggregate"]

    macro_floor = f"{macro['macro_invariant_floor']:.1f}"
    macro_s0 = round_half_up(macro["macro_mean_initial_s0"], 1)
    macro_full_s = round_half_up(macro["macro_full_schema_s"], 1)
    macro_sav = round_half_up(macro["exact_macro_mean_savings_pct"], 1)
    macro_fp = f"\\textbf{{{macro['macro_first_pass_pct']:.1f}\\%}} (16/16, 0/16)"
    macro_st = f"\\textbf{{{macro['macro_final_struct_pct']:.1f}\\%}}"
    macro_sem = f"\\textbf{{{macro['macro_semantic_pct']:.1f}\\%}}"
    macro_amb = f"\\textbf{{{macro['macro_ambiguous_recovery_pct']:.1f}\\%}} (16/16)"

    pooled_sav = round_half_up(pooled["exact_pooled_savings_pct"], 1)

    rows_tex = "\n".join(rows)

    content = f"""\\begin{{table*}}[t]
\\centering
\\caption{{Cross-Schema Mechanism Stress Test across Four Heterogeneous Enterprise Domains ($N=32$ Tasks total, 8 per Schema)}}
\\label{{tab:cross_schema}}
\\resizebox{{\\textwidth}}{{!}}{{%
\\begin{{tabular}}{{llcccccccc}}
\\toprule
\\textbf{{Enterprise-Style Tool Schema}} & \\textbf{{Domain / Key Constraints}} & \\textbf{{Floor $C_I^*$}} & \\textbf{{Mean $S_0$}} & \\textbf{{Full $S$}} & \\textbf{{Workload Savings}} & \\textbf{{1st-Pass (Exp/Amb)}} & \\textbf{{Final Struct.}} & \\textbf{{Semantic}} & \\textbf{{Ambiguous Recovery}} \\\\
\\midrule
{rows_tex}
\\midrule
\\textbf{{Unweighted Macro Mean}} & Four-Domain Average ($N=4$ domains) & \\textbf{{{macro_floor}}} & \\textbf{{{macro_s0}}} & \\textbf{{{macro_full_s}}} & \\textbf{{{macro_sav}\\%}} & {macro_fp} & {macro_st} & {macro_sem} & {macro_amb} \\\\
\\textbf{{Pooled Workload Aggregate}} & Total Workload Tokens ($N=32$ tasks) & -- & -- & -- & \\textbf{{{pooled_sav}\\%}} & {macro_fp} & {macro_st} & {macro_sem} & {macro_amb} \\\\
\\bottomrule
\\end{{tabular}}%
}}
\\vspace{{1mm}}
\\begin{{minipage}}{{\\textwidth}}
\\footnotesize
\\textit{{Note}}: Evaluated across 32 tasks (4 schemas $\\times$ 8 tasks) under a deterministic simulation-based mechanism stress test using whitespace/punctuation heuristic token estimates. Workload savings measure total token reduction relative to monolithic full schema. The \\textbf{{Unweighted Macro Mean}} (22.3\\%) averages unrounded per-domain percentage reductions $(21.2691\\% + 22.3935\\% + 25.1936\\% + 20.4859\\%) / 4 = 22.3355\\%$, while the three new domains average 22.7\\% ($(22.3935\\% + 25.1936\\% + 20.4859\\%) / 3 = 22.691\\%$). The \\textbf{{Pooled Workload Aggregate}} (22.5\\%) computes total token reduction across all 64 per-task records ($54,657 \\rightarrow 42,369$ tokens across 4 schemas). In this deterministic simulation, both arms share identical modeled structural and recovery outcomes (16/32 first-pass, 32/32 final structural, 30/32 semantic); reported savings reflect lower token exposure under matched simulated completion outcomes. \\textbf{{Floor $C_I^*$}} denotes the schema invariant token floor; \\textbf{{Mean $S_0$}} denotes the actual initial active schema size across evaluated tasks (macro mean: 361.3).
\\end{{minipage}}
\\end{{table*}}
"""
    return content

def generate_all_tables() -> List[str]:
    TABLES_DIR.mkdir(parents=True, exist_ok=True)
    generated = []

    # 1. Load frozen primary benchmark
    frozen_path = WORKSPACE / "datasets" / "frozen_benchmark_n32" / "invariant_optimization_summary.json"
    with open(frozen_path, "r", encoding="utf-8") as fp:
        frozen_data = json.load(fp)

    # 2. Derive cross-schema summary
    import version_2.derive_cross_schema_metrics as dcsm
    cross_summary = dcsm.derive_metrics()

    # Table 1
    t1_content = generate_table1(frozen_data)
    t1_path = TABLES_DIR / "table1_systems_evaluation.tex"
    t1_path.write_text(t1_content, encoding="utf-8")
    generated.append(str(t1_path))

    # Table 2
    t2_content = generate_table2(frozen_data)
    t2_path = TABLES_DIR / "table2_paired_bootstrap.tex"
    t2_path.write_text(t2_content, encoding="utf-8")
    generated.append(str(t2_path))

    # Table 3
    t3_content = generate_table3(frozen_data)
    t3_path = TABLES_DIR / "table3_cluster_breakdown.tex"
    t3_path.write_text(t3_content, encoding="utf-8")
    generated.append(str(t3_path))

    # Table 4
    t4_content = generate_table4(cross_summary)
    t4_path = TABLES_DIR / "table4_cross_schema.tex"
    t4_path.write_text(t4_content, encoding="utf-8")
    generated.append(str(t4_path))

    print(f"Generated {len(generated)} tables strictly in {TABLES_DIR.relative_to(WORKSPACE)}:")
    for g in generated:
        print(f"  - {Path(g).name}")
    return generated

if __name__ == "__main__":
    generate_all_tables()
