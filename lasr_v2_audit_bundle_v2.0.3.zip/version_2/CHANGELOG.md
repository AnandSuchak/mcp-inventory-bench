# Changelog: LASR-MCP Version 2

All notable changes to the LASR-MCP Version 2 benchmark, audit tools, and manuscripts are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to Semantic Versioning for its release packaging. Note that release versions track software/audit releases and are kept separate from scientific manuscript version designations.

---

## [2.0.3] - 2026-10-18

### Added
- **Single Source of Versioning**: Created `version_2/RELEASE_VERSION` containing `2.0.3` as the authoritative version reference across builder, verifier, reconciler, and attestations.
- **Canonical Metric Reconciliation (`version_2/reconcile_canonical_metrics.py`)**: Unified programmatic pipeline that derives `version_2/canonical_metrics.json` directly from raw frozen evidence across primary benchmark, latency hierarchy, diagnostic retrieval curves, cross-schema stress test, and LangGraph counterfactual model. Separates `--check` (pure read-only audit) from `--regenerate`.
- **Pure In-Memory Cross-Schema Derivation**: Refactored `version_2/derive_cross_schema_metrics.py` to run purely in-memory by default (`export=False`), eliminating false-pass risks from silent summary overwrites during verification.
- **Complete Diagnostic Retrieval Curves**: Implemented deterministic tie-breaking in `version_2/run_dense_rag_baseline.py` exporting full curves for $k \in \{1, 2, 3, 5\}$ to `version_2/dense_rag_evaluation.json` and `version_2/retrieval_evaluation_curve.csv`.
- **Reusable Production Archive Validator**: Hardened `create_audit_zip.py` with case-insensitive duplicate checks, path traversal guards, prohibited member detection, and atomic archive deployment.
- **Exhaustive Verifier Regression Suite (`version_2/test_verifier_regressions.py`)**: 13-part test suite validating manifest directory traversal rejection, duplicate entry rejection, corrupted hash detection, archive path omission, nested ZIP rejection, table tampering detection, graceful missing packager failure handling, dependency failure handling, and non-mutating audit behavior.
- **Pinned Audit Dependencies (`requirements-audit.txt`)**: Pinned `numpy==2.2.2` and `scikit-learn==1.9.1` for exact audit environment reproducibility.
- **Paper Tables Generator (`version_2/generate_paper_tables_v2.py`)**: Programmatic script generating Tables I, II, III, IV directly into `version_2/paper_v2/tables/` matching canonical metrics.
- **Detached Post-Packaging Release Attestation**: Structured `.attestation.json` and `.attestation.md` sidecars created strictly external to the archive after clean-extraction verification.

### Fixed
- **Verifier Crash Prevention**: Eliminated `UnboundLocalError` vulnerabilities across all verification checks by structuring every check as an isolated dictionary with guaranteed variable initialization.
- **Strict Manifest Validation**: Upgraded `parse_and_validate_manifest` to reject directory traversal (`..`), absolute paths, duplicate entries, malformed hex hashes, and empty paths, enforcing that all resolved paths remain strictly within the manifest directory. Added sibling `metadata.json` (`ab8ca76d...`) to `datasets/frozen_benchmark_n32/MANIFEST.sha256`.
- **First-Pass Structural Display**: Standardized first-pass structural percentage to `31.3%` ($10/32 = 31.25\%$, decimal `ROUND_HALF_UP`) across CSV, JSON, and LaTeX tables.
- **Hypothesis H1 Reporting Alignment**: Synchronized statistical test reporting across abstract, intro, and results: $\Delta F_1 = +0.613$ (unrounded $+0.6125$, 95% CI $[+0.419, +0.781]$, permutation $p < 0.001$).
- **Cross-Schema S0 Semantics & Token Accounting**: Corrected Table IV note from legacy $66,720 \rightarrow 51,708$ to canonical $54,657 \rightarrow 42,369$ tokens (22.5% pooled savings). Disambiguated Invariant Floor ($C_I^*$, macro 316.8) from Mean Initial $S_0$ (macro 361.3) across all 4 synthetic schemas. Distinguishes 4-domain macro savings (22.3%, unrounded 22.3355%) and 3-new-domain macro savings (22.7%, unrounded 22.691%) from pooled aggregate (22.5%).
- **Cross-Schema Scientific Epistemology**: Updated manuscript sections 05 and 07, Table IV, and documentation to accurately describe the cross-schema study as a deterministic simulation-based mechanism stress test with heuristic token counts, clarifying that live model API calls were conducted exclusively on the primary benchmark.
- **Honest Theorem Validation Scope**: Renamed Check 7 from formal mathematical proof to source-invariant check, pairing it with a comprehensive human-review checklist.
- **Environment Provenance & Compilation Status**: Documented temperature 0.2, absence of decoding seeds / provider-resolved modelVersion strings in archived cache traces, and documented `BLOCKED` status for local PDF compilation due to lack of `pdflatex` binary in Windows OS environment while maintaining clean, verified LaTeX source trees.
- **README Relative Links**: Replaced nonportable `file:///c:/paper/mcp/...` URIs with clean relative repository links.

---

## [2.0.2] - 2026-10-16

### Added
- **Direct Manifest Validation (Check 1)**: Implemented an active parser and integrity checker for both `MANIFEST.sha256` files (`datasets/frozen_benchmark_n32/MANIFEST.sha256` and `datasets/cross_schema_validation/MANIFEST.sha256`). Rejects malformed lines, missing files, and hash mismatches while retaining independently pinned trusted hashes (`78c2c88e...` and `b3d57636...`) to prevent manifest tampering.
- **Behavioral Packaging Verification (Check 9)**: Upgraded Check 9 from static string-searching to an active behavioral packaging test. The verifier now executes `create_audit_zip.py` into a controlled temporary directory, inspects the generated zip, and verifies the presence of root `create_audit_zip.py`, Version 2 tree, frozen datasets, cross-schema datasets, exactly 556 cache traces, and trace sources.
- **Behavioral & Negative Test Suite (`version_2/test_packaging_behavior.py`)**: Created an automated test suite verifying that Check 9 detects and rejects omitted source trees even if the packager script still contains the folder name as a string.
- **Audit Stage Identification & Release Attestation**: Added `--stage` flag to `verify_version_2_integrity.py` distinguishing `pre_packaging_audit` from `clean_extraction_verification`. Created standalone post-package release attestation (`version_2/RELEASE_ATTESTATION_2.0.2.md` and `version_2/release_attestation_v2.0.2.json`).
- **LaTeX Transient Build Artifact Policy**: Explicitly configured `create_audit_zip.py` to filter transient files (`.aux`, `.log`, `.fls`, `.out`, `.fdb_latexmk`, `.bbl`, `.blg`, `.synctex.gz`, `.toc`), preventing archive drift from local compilation passes.

### Fixed
- **Math Mode Font Command**: Removed misplaced `\small` text font command from inside `\begin{equation}` in `version_2/paper_v2/sections/02_system_architecture.tex`, resolving LaTeX font warnings in math mode.
- **SHA-256 Overfull Line**: Wrapped the 64-character SHA-256 hash in `version_2/paper_v2/sections/03_experimental_setup.tex` across two balanced lines, preventing gutter intrusion and column overflow.
- **Table I Overfull Width**: Wrapped `version_2/paper_v2/tables/table1_systems_evaluation.tex` in `\resizebox{\textwidth}{!}` with a separated minipage footnote note, eliminating overfull horizontal box warnings.

### Changed Files
1. `create_audit_zip.py`:
   - Updated default output to `lasr_v2_audit_bundle_v2.0.2.zip`.
   - Added `LATEX_TRANSIENT_EXTS` exclusion policy (`.aux`, `.log`, `.fls`, `.out`, etc.).
   - Added support for absolute and relative paths via `--out`.
2. `version_2/verify_version_2_integrity.py`:
   - Check 1: Added `parse_and_validate_manifest` to parse and verify `MANIFEST.sha256` files directly against disk files, alongside trusted pinned hashes.
   - Check 8: Added validation of math mode `\small` removal, SHA-256 wrapping, and Table I resizebox.
   - Check 9: Replaced string matching with dynamic behavioral packaging test in controlled temp directory, verifying 556 cache traces, root packager, zero nested zips, and zero transient files.
   - Added `--stage` parameter and factual reporting.
3. `version_2/paper_v2/sections/02_system_architecture.tex`:
   - Removed `\small` inside equation (38).
4. `version_2/paper_v2/sections/03_experimental_setup.tex`:
   - Formatted cryptographic provenance hash to fit single column width.
5. `version_2/paper_v2/tables/table1_systems_evaluation.tex`:
   - Added `\resizebox{\textwidth}{!}` and separated footnote note.
6. `version_2/test_packaging_behavior.py`:
   - Added test suite for behavioral packaging and negative omission detection.
7. `version_2/CHANGELOG.md`:
   - Added Version 2.0.2 entry.
8. `version_2/RELEASE_NOTES_2.0.2.md`:
   - Created release notes for Version 2.0.2.
9. `version_2/README_V2.md`:
   - Updated inventory and documentation for Version 2.0.2.

---

## [2.0.1] - 2026-10-16

### Fixed
- **Reproducible Archive Verification Defect (Check 9)**: Resolved an issue where running `verify_version_2_integrity.py` inside a freshly extracted release archive crashed with an uncaught `FileNotFoundError` because `create_audit_zip.py` had not been included in the root of the generated zip bundle.
- **Archive Self-Inclusion**: Enhanced `create_audit_zip.py` to explicitly exclude all `*.zip` files and temporary extraction directories (`temp_*`, `test_*`, `tmp/`), preventing accidental recursive zip-in-zip bloat.
- **Graceful Error Handling in Verifier**: Updated `version_2/verify_version_2_integrity.py` so that missing files across all 9 checks produce structured failure reports (`passed: false` with actionable diagnostic messages) rather than unhandled Python exceptions.
- **Unconditional Audit Certificate Generation**: Guaranteed that `version_2/verification_audit_certificate.json` is exported even when checks fail, recording exact passed/failed check counts and failure details.
- **Dynamic Runtime Timestamp**: Replaced hardcoded historical timestamp with runtime ISO 8601 timestamp (`datetime.now(timezone.utc).astimezone().isoformat()`).

### Changed Files
1. `create_audit_zip.py`:
   - Added `create_audit_zip.py` to `include_paths` with root arcname.
   - Added `*.zip` filtering and temporary directory exclusion during walk.
   - Added `--out` command line argument, defaulting to `lasr_v2_audit_bundle_v2.0.1.zip`.
2. `version_2/verify_version_2_integrity.py`:
   - Updated Check 9 to verify existence of `create_audit_zip.py` at workspace root, inclusion of all 5 source trees (`version_2`, `datasets/frozen_benchmark_n32`, `datasets/cross_schema_validation`, `datasets/cache`, `trace`), self-inclusion, and `.zip` exclusion.
   - Guarded Checks 1–8 with file existence validations and descriptive error details.
   - Replaced static timestamp with dynamic runtime timestamp.
   - Added release version tag `2.0.1` to exported certificate.
3. `version_2/README_V2.md`:
   - Documented Version 2.0.1 controlled patch and updated file inventory.
4. `version_2/CHANGELOG.md`:
   - Created this changelog documenting 2.0.0 baseline and 2.0.1 patch.
5. `version_2/RELEASE_NOTES_2.0.1.md`:
   - Published release notes for Version 2.0.1.

---

## [2.0.0] - 2026-10-16

### Baseline Snapshot
- **Baseline Archive**: `lasr_v2_audit_bundle.zip` (SHA-256: `36cf1def3de7bde589c02839b26ed10ac0fb2ec923eaffb46282e96e43fd00f3`).
- **Mathematical Bound Correction**: Proved finite monotonic recovery bound $K \le M - |A_0|$ in `version_2/formal_termination_proof.tex` and `version_2/paper_v2/sections/02_system_architecture.tex`. Disproved heuristic depth bound $K \le D$ via sibling-leaf counterexample.
- **LaTeX Proof Environment**: Defined `\begin{IEEEproof}` environments compliant with `IEEEtran.cls`.
- **Table Formatting Fixes**: Resolved Table V single-column overflow using `\resizebox{\columnwidth}{!}` and replaced cross-schema pooled row schema sizes with `-- & --` in Table IV.
- **Retrieval Baselines Decoupling**: Recomputed Lexical TF-IDF Macro Recall@2 (12.5%, 75.0% zero-hits) and Inductive LSA SVD-16 Macro Recall@2 (14.06%, 71.9% zero-hits). Marked retrieval rows in Table V as `NOT MEASURED (Retrieval-Only)` to prevent conflation with end-to-end validator execution.
- **LangGraph Counterfactual Model**: Characterized LangGraph state accumulation as a trace-derived counterfactual token model (+45 tok compiler context, 103,895 tokens, +7.52% overhead / -7.52% net savings).
- **Latency Benchmarking**: Measured local in-tree AST recomposition latency across 1,000 iterations ($p_{50} = 20.1\ \mu\text{s}$) against 556 empirical API response traces ($p_{50} = 3,407.1\text{ ms}$), showing an overhead ratio of $0.00059\%$.
- **Version 1 Immutability**: All original Version 1 files (`paper/main.pdf`, `paper/`, `datasets/`, `trace/`, `README.md`) preserved 100% untouched.
