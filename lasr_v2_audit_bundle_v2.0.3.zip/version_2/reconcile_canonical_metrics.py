#!/usr/bin/env python3
"""
Canonical Metric Reconciliation & Consistency Validator (Version 2.0.3)
Project: mcp-inventory-bench / Version 2.0.3
Author: Anand S. Suchak

Recomputes all canonical benchmark metrics directly from raw frozen datasets:
1. Primary Benchmark (N=32 Gemini Flash-Lite evaluation runs across 6 arms)
2. Empirical Model Turnaround & AST Latency Hierarchy (556 cache traces, 1000 AST samples, Monte Carlo task trajectory)
3. Diagnostic Schema Retrieval Curves (TF-IDF & LSA/TruncatedSVD at k=1,2,3,5 computed in-memory)
4. Cross-Schema Mechanism Stress Test (N=64 per-task simulation records across 4 domains derived in-memory)
5. LangGraph Counterfactual State Accumulation Model (N=32 modeled trajectories)
6. H1 Intent Prediction Evaluation (N=32 tasks, 10,000 bootstrap replicates)

Modes:
- --check (default): Pure read-only audit. Computes canonical metrics in memory,
  verifies disk artifacts (canonical_metrics.json, tables, prose, CSVs) without touching them.
- --regenerate: Explicit operator command. Computes canonical metrics, compares with existing,
  reports differences, and safely updates version_2/canonical_metrics.json.
- --test-regression: Verifies that tampering with reported values triggers check failure.
"""

import sys
import os
import glob
import json
import csv
import math
import random
import hashlib
import statistics
import argparse
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional

WORKSPACE = Path(__file__).resolve().parent.parent
if str(WORKSPACE) not in sys.path:
    sys.path.insert(0, str(WORKSPACE))

def round_half_up(val: float, decimals: int = 1) -> float:
    d = Decimal(str(val))
    fmt = "0." + "0" * decimals if decimals > 0 else "0"
    return float(d.quantize(Decimal(fmt), rounding=ROUND_HALF_UP))

def compute_file_sha256(filepath: Path) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def percentile(vals: List[float], p: float) -> float:
    if not vals:
        return 0.0
    sorted_vals = sorted(vals)
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    pos = (len(sorted_vals) - 1) * p
    lo, hi = math.floor(pos), math.ceil(pos)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (pos - lo)

def derive_primary_benchmark(workspace: Path) -> Dict[str, Any]:
    rel_path = "datasets/frozen_benchmark_n32/invariant_optimization_summary.json"
    raw_path = workspace / rel_path
    if not raw_path.exists():
        raise FileNotFoundError(f"Missing raw frozen benchmark: {raw_path}")
    
    file_hash = compute_file_sha256(raw_path)
    
    with open(raw_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    sb = data.get("systems_benchmark", {})
    expected_arms = ["full", "ci_k1_reactive", "ci_k2_reactive", "ci_k1_static", "ci_k0", "oracle_reactive"]
    for arm in expected_arms:
        if arm not in sb:
            raise KeyError(f"Missing arm {arm} in systems_benchmark")
            
    arm_task_ids = {}
    canonical_arms = {}
    for arm in expected_arms:
        recs = sb[arm].get("records", [])
        if len(recs) != 32:
            raise ValueError(f"Arm {arm} has {len(recs)} records; expected 32")
        t_ids = [r["task_id"] for r in recs]
        if len(set(t_ids)) != 32:
            raise ValueError(f"Duplicate task IDs in arm {arm}")
        arm_task_ids[arm] = sorted(t_ids)
        
        total_tokens = 0
        attempt_tokens = 0
        struct_succ = 0
        sem_succ = 0
        tts_vals = []
        first_pass_struct = 0
        
        for r in recs:
            tot = r.get("total_tokens_consumed", 0)
            total_tokens += tot
            att_sum = sum(a.get("tokens", 0) for a in r.get("attempts", []))
            attempt_tokens += att_sum
            if tot != att_sum:
                raise ValueError(f"Attempt sum mismatch in arm {arm}, task {r.get('task_id')}: {tot} != {att_sum}")
            if r.get("first_pass_structural"):
                first_pass_struct += 1
            if r.get("final_structural_success"):
                struct_succ += 1
                tts_vals.append(r.get("total_tts", 0))
            if r.get("final_semantic_correctness"):
                sem_succ += 1
                
        mean_tts = statistics.mean(tts_vals) if tts_vals else 0.0
        canonical_arms[arm] = {
            "tasks_count": 32,
            "total_workload_tokens": total_tokens,
            "mean_tokens_per_task": round(total_tokens / 32.0, 1),
            "first_pass_structural_count": first_pass_struct,
            "first_pass_structural_pct": round_half_up((first_pass_struct / 32.0) * 100.0, 1),
            "first_pass_structural_pct_unrounded": round((first_pass_struct / 32.0) * 100.0, 4),
            "final_structural_success_count": struct_succ,
            "final_structural_success_pct": round_half_up((struct_succ / 32.0) * 100.0, 1),
            "final_semantic_correctness_count": sem_succ,
            "final_semantic_correctness_pct": round_half_up((sem_succ / 32.0) * 100.0, 1),
            "mean_tts_conditioned_on_success": round(mean_tts, 1)
        }
    
    ref_tasks = arm_task_ids["full"]
    for arm, t_ids in arm_task_ids.items():
        if t_ids != ref_tasks:
            raise ValueError(f"Task ID mismatch between 'full' and '{arm}'")
            
    full_tokens = canonical_arms["full"]["total_workload_tokens"]
    full_tts = canonical_arms["full"]["mean_tts_conditioned_on_success"]
    
    for arm, stats in canonical_arms.items():
        tot = stats["total_workload_tokens"]
        stats["workload_token_savings_pct"] = round(((full_tokens - tot) / full_tokens) * 100.0, 2)
        tts = stats["mean_tts_conditioned_on_success"]
        stats["tts_token_savings_pct"] = round(((full_tts - tts) / full_tts) * 100.0, 2)
        
    return {
        "status": "VERIFIED_PRIMARY_BENCHMARK",
        "reference_dataset": rel_path,
        "source_sha256": file_hash,
        "formula": "workload_token_savings_pct = (full_tokens - arm_tokens) / full_tokens * 100",
        "arms": canonical_arms
    }

def derive_latencies(workspace: Path) -> Dict[str, Any]:
    cache_files = sorted(glob.glob(str(workspace / "datasets" / "cache" / "*.json")))
    if len(cache_files) != 556:
        raise ValueError(f"Expected 556 cache traces, found {len(cache_files)}")
    
    latencies = []
    for cf in cache_files:
        with open(cf, "r", encoding="utf-8") as f:
            rec = json.load(f)
        if "lat" not in rec or type(rec["lat"]) not in (int, float) or math.isnan(rec["lat"]) or math.isinf(rec["lat"]) or rec["lat"] < 0:
            raise ValueError(f"Invalid or non-finite 'lat' field in cache trace {cf}")
        latencies.append(float(rec["lat"]))
        
    req_p50 = percentile(latencies, 0.50)
    req_p90 = percentile(latencies, 0.90)
    req_p95 = percentile(latencies, 0.95)
    req_p99 = percentile(latencies, 0.99)
    req_mean = statistics.mean(latencies)
    req_stdev = statistics.stdev(latencies)
    
    ast_rel = "version_2/latency_benchmark_measurements.csv"
    ast_file = workspace / ast_rel
    if not ast_file.exists():
        raise FileNotFoundError(f"Missing AST latency CSV: {ast_file}")
    
    ast_hash = compute_file_sha256(ast_file)
    ast_samples = []
    with open(ast_file, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if row and row[0].isdigit() and len(row) >= 9:
                val = float(row[8])
                if math.isnan(val) or math.isinf(val) or val < 0:
                    raise ValueError(f"Invalid non-finite latency measurement in CSV: {row}")
                ast_samples.append(val)
                
    if len(ast_samples) != 1000:
        raise ValueError(f"Expected 1000 AST latency samples, found {len(ast_samples)}")
        
    ast_p50 = percentile(ast_samples, 0.50)
    ast_p90 = percentile(ast_samples, 0.90)
    ast_p99 = percentile(ast_samples, 0.99)
    ast_mean = statistics.mean(ast_samples)
    
    ast_to_req_p50_ratio_pct = (ast_p50 / req_p50) * 100.0
    
    random.seed(42)
    attempt_weights = [1] * 6 + [2] * 20 + [3] * 6
    sim_trajectories = []
    for _ in range(10000):
        k = random.choice(attempt_weights)
        sim_trajectories.append(sum(random.choice(latencies) for _ in range(k)))
        
    sim_p50 = percentile(sim_trajectories, 0.50)
    sim_p90 = percentile(sim_trajectories, 0.90)
    sim_p99 = percentile(sim_trajectories, 0.99)
    sim_mean = statistics.mean(sim_trajectories)
    
    return {
        "status": "VERIFIED_LATENCY_HIERARCHY",
        "provenance": {
            "cache_traces_count": len(cache_files),
            "ast_measurements_csv": ast_rel,
            "ast_measurements_sha256": ast_hash
        },
        "request_level_model_turnaround_ms": {
            "samples": len(latencies),
            "p50_ms": round(req_p50, 2),
            "p90_ms": round(req_p90, 2),
            "p95_ms": round(req_p95, 2),
            "p99_ms": round(req_p99, 2),
            "mean_ms": round(req_mean, 2),
            "stdev_ms": round(req_stdev, 2)
        },
        "local_ast_pipeline_latency_ms": {
            "samples": len(ast_samples),
            "p50_ms": round(ast_p50, 4),
            "p50_us": round(ast_p50 * 1000, 1),
            "p90_ms": round(ast_p90, 4),
            "p99_ms": round(ast_p99, 4),
            "p99_us": round(ast_p99 * 1000, 1),
            "mean_ms": round(ast_mean, 6),
            "overhead_ratio_to_request_p50_pct": round(ast_to_req_p50_ratio_pct, 5),
            "ratio_display": f"{ast_to_req_p50_ratio_pct:.5f}%"
        },
        "simulated_task_trajectory_turnaround_ms": {
            "methodology": "Monte Carlo convolution over empirical attempts (10,000 samples, seed=42)",
            "attempts_distribution": {"1_attempt": 6, "2_attempts": 20, "3_attempts": 6},
            "p50_ms": round(sim_p50, 2),
            "p90_ms": round(sim_p90, 2),
            "p99_ms": round(sim_p99, 2),
            "mean_ms": round(sim_mean, 2)
        }
    }

def derive_retrieval(workspace: Path) -> Dict[str, Any]:
    from version_2.run_dense_rag_baseline import compute_retrieval_metrics
    schema_path = workspace / "version_2" / "full_schema.json"
    tasks_path = workspace / "version_2" / "benchmark_tasks_n32.json"
    
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = json.load(f)
    with open(tasks_path, "r", encoding="utf-8") as f:
        tasks = json.load(f)
        
    report, csv_rows = compute_retrieval_metrics(schema, tasks)
    tfidf = report.get("tfidf_results", {})
    lsa = report.get("lsa_results", {})
    
    return {
        "status": "VERIFIED_RETRIEVAL_DIAGNOSTICS",
        "description": "Inductive LSA and Lexical TF-IDF diagnostic recall on 32 tasks vs 27 schema chunks",
        "source_schema": "version_2/full_schema.json",
        "source_tasks": "version_2/benchmark_tasks_n32.json",
        "tfidf_curve": tfidf,
        "lsa_curve": lsa
    }

def derive_cross_schema(workspace: Path) -> Dict[str, Any]:
    import version_2.derive_cross_schema_metrics as dcsm
    raw_path = workspace / "datasets" / "cross_schema_validation" / "cross_schema_results.json"
    if not raw_path.exists():
        raise FileNotFoundError(f"Missing cross-schema results: {raw_path}")
    raw_hash = compute_file_sha256(raw_path)
    derived = dcsm.derive_metrics(raw_path)
    
    return {
        "status": "VERIFIED_CROSS_SCHEMA_STRESS_TEST",
        "study_characterization": "Deterministic simulation-based mechanism stress test (word/punctuation heuristic token estimates)",
        "source_dataset": "datasets/cross_schema_validation/cross_schema_results.json",
        "source_sha256": raw_hash,
        "derived_summary": derived
    }

def derive_langgraph(workspace: Path) -> Dict[str, Any]:
    lg_rel = "version_2/langgraph_traces.json"
    lg_path = workspace / lg_rel
    if not lg_path.exists():
        raise FileNotFoundError(f"Missing LangGraph traces: {lg_path}")
    lg_hash = compute_file_sha256(lg_path)
    with open(lg_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        
    trajs = data.get("trajectories", [])
    if len(trajs) != 32:
        raise ValueError(f"Expected 32 LangGraph trajectories, found {len(trajs)}")
    
    tot_tokens = sum(t["total_tokens_consumed"] for t in trajs)
    if tot_tokens != 103895:
        raise ValueError(f"LangGraph total tokens mismatch: {tot_tokens} != 103895")
        
    for t in trajs:
        att_sum = sum(a["total_attempt_tokens"] for a in t["attempts"])
        if t["total_tokens_consumed"] != att_sum:
            raise ValueError(f"LangGraph attempt sum mismatch for task {t['task_id']}")
            
    return {
        "status": "VERIFIED_LANGGRAPH_COUNTERFACTUAL",
        "characterization": "Counterfactual state-history accumulation token model (+45 tok compiler context)",
        "source_dataset": lg_rel,
        "source_sha256": lg_hash,
        "total_workload_tokens": tot_tokens,
        "mean_tokens_per_task": round(tot_tokens / 32.0, 1),
        "overhead_vs_full_schema_pct": round(((tot_tokens - 96629) / 96629) * 100.0, 2),
        "savings_lasr_k2_vs_langgraph_pct": round(((tot_tokens - 75248) / tot_tokens) * 100.0, 2),
        "overhead_vs_lasr_k2_pct": round(((tot_tokens - 75248) / 75248) * 100.0, 2)
    }

def derive_h1_predictor(workspace: Path) -> Dict[str, Any]:
    h1_rel = "version_2/h1_predictor_evaluation.json"
    h1_path = workspace / h1_rel
    if not h1_path.exists():
        import version_2.reproduce_h1_predictor as rh1
        rh1.evaluate_h1_predictor(export=True)
    h1_hash = compute_file_sha256(h1_path)
    with open(h1_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return {
        "status": "VERIFIED_H1_PREDICTOR",
        "source_dataset": h1_rel,
        "source_sha256": h1_hash,
        "evaluation_summary": data["metrics_summary"],
        "overlap_analysis": data["overlap_analysis"]
    }

def derive_all_canonical_metrics(workspace: Path) -> Dict[str, Any]:
    return {
        "release_version": "2.0.3",
        "provenance": {
            "generator": "version_2/reconcile_canonical_metrics.py",
            "workspace_relative": "version_2",
            "primary_source_hashes": {
                "datasets/frozen_benchmark_n32/invariant_optimization_summary.json": "78c2c88ed5128e0f296fa29e0c258589b516f3adb14b0b8da491fa73bc3ffc11",
                "datasets/cross_schema_validation/cross_schema_results.json": "b3d57636f9834ff536204acfe88454c9620228bb67705f1b3caa40e0d562302a"
            }
        },
        "primary_benchmark": derive_primary_benchmark(workspace),
        "latency_hierarchy": derive_latencies(workspace),
        "retrieval_diagnostics": derive_retrieval(workspace),
        "cross_schema_stress_test": derive_cross_schema(workspace),
        "langgraph_counterfactual": derive_langgraph(workspace),
        "h1_intent_prediction": derive_h1_predictor(workspace)
    }

def audit_check(workspace: Path) -> Tuple[bool, List[str]]:
    """
    Pure read-only audit check. Does not overwrite or touch any files on disk.
    Computes expected canonical metrics in memory, compares with existing disk artifacts.
    """
    errors = []
    
    # 1. Check canonical_metrics.json existence
    canon_path = workspace / "version_2" / "canonical_metrics.json"
    if not canon_path.exists():
        errors.append(f"Missing canonical artifact: {canon_path}. Run with --regenerate to initialize.")
        return False, errors
        
    try:
        with open(canon_path, "r", encoding="utf-8") as f:
            disk_canon = json.load(f)
    except Exception as e:
        errors.append(f"Failed to parse {canon_path}: {e}")
        return False, errors

    # Check for machine-specific paths in disk_canon
    canon_text = canon_path.read_text(encoding="utf-8")
    if "C:\\" in canon_text or "c:\\" in canon_text or "file:///c:" in canon_text or "file:///C:" in canon_text:
        errors.append("canonical_metrics.json: Machine-specific absolute paths detected in artifact")

    # 2. Derive canonical metrics in memory from pinned sources
    try:
        in_mem_canon = derive_all_canonical_metrics(workspace)
    except Exception as e:
        errors.append(f"In-memory canonical derivation failed: {e}")
        return False, errors

    # 3. Compare key fields between disk_canon and in_mem_canon
    pb_disk = disk_canon.get("primary_benchmark", {}).get("arms", {})
    pb_mem = in_mem_canon.get("primary_benchmark", {}).get("arms", {})
    for arm in ["full", "ci_k1_reactive", "ci_k2_reactive", "ci_k1_static"]:
        if arm not in pb_disk:
            errors.append(f"canonical_metrics.json: Missing arm '{arm}'")
            continue
        d_tok = pb_disk[arm].get("total_workload_tokens")
        m_tok = pb_mem[arm].get("total_workload_tokens")
        if d_tok != m_tok:
            errors.append(f"canonical_metrics.json: Arm '{arm}' tokens mismatch: disk={d_tok}, derived={m_tok}")
        d_fp = pb_disk[arm].get("first_pass_structural_pct")
        m_fp = pb_mem[arm].get("first_pass_structural_pct")
        if d_fp != m_fp:
            errors.append(f"canonical_metrics.json: Arm '{arm}' first_pass mismatch: disk={d_fp}, derived={m_fp}")

    # Latency comparison
    lat_disk = disk_canon.get("latency_hierarchy", {}).get("local_ast_pipeline_latency_ms", {})
    lat_mem = in_mem_canon.get("latency_hierarchy", {}).get("local_ast_pipeline_latency_ms", {})
    if lat_disk.get("p50_us") != lat_mem.get("p50_us"):
        errors.append(f"canonical_metrics.json: AST p50_us mismatch: disk={lat_disk.get('p50_us')}, derived={lat_mem.get('p50_us')}")
    if lat_disk.get("ratio_display") != lat_mem.get("ratio_display"):
        errors.append(f"canonical_metrics.json: Latency ratio display mismatch: disk={lat_disk.get('ratio_display')}, derived={lat_mem.get('ratio_display')}")

    # Cross-schema comparison
    cs_disk = disk_canon.get("cross_schema_stress_test", {}).get("derived_summary", {})
    cs_mem = in_mem_canon.get("cross_schema_stress_test", {}).get("derived_summary", {})
    disk_macro_sav = cs_disk.get("unweighted_macro_mean", {}).get("exact_macro_mean_savings_pct")
    mem_macro_sav = cs_mem.get("unweighted_macro_mean", {}).get("exact_macro_mean_savings_pct")
    if disk_macro_sav != mem_macro_sav:
        errors.append(f"canonical_metrics.json: Cross-schema macro savings mismatch: disk={disk_macro_sav}, derived={mem_macro_sav}")

    # 4. Check cross_schema_derived_summary.json on disk matches in-memory derivation
    cs_path = workspace / "version_2" / "cross_schema_derived_summary.json"
    if not cs_path.exists():
        errors.append(f"Missing {cs_path}")
    else:
        with open(cs_path, "r", encoding="utf-8") as f:
            cs_disk_summary = json.load(f)
        val = cs_disk_summary.get("pooled_workload_aggregate", {}).get("pooled_workload_savings_pct")
        if val != 22.5:
            errors.append(f"cross_schema_derived_summary.json: pooled_workload_savings_pct != 22.5 (found {val})")
        if cs_disk_summary.get("unweighted_macro_mean", {}).get("exact_macro_mean_savings_pct") != cs_mem["unweighted_macro_mean"]["exact_macro_mean_savings_pct"]:
            errors.append("cross_schema_derived_summary.json: macro savings does not match in-memory derivation")

    # 5. Check baseline_comparison_table.csv
    csv_path = workspace / "version_2" / "baseline_comparison_table.csv"
    if not csv_path.exists():
        errors.append(f"Missing {csv_path}")
    else:
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = {r["Architecture / Arm"]: r for r in reader}
            
        full_row = rows.get("Full Schema (Draft 2020-12)")
        if not full_row or full_row.get("Total Workload Tokens (32 Tasks)") != "96629":
            errors.append("baseline_comparison_table.csv: Full schema tokens mismatch (expected 96629)")
        if not full_row or "31.3%" not in full_row.get("First-Pass Structural %", "") and "31.25%" not in full_row.get("First-Pass Structural %", ""):
            # Under half-up rounding, 10/32 = 31.25% displayed as 31.3%
            if full_row and full_row.get("First-Pass Structural %") == "31.2%":
                errors.append("baseline_comparison_table.csv: Stale tie-to-even first pass 31.2% (should be 31.3%)")
            
        k2_row = rows.get("LASR-MCP (k=2 Reactive Recovery)")
        if not k2_row or k2_row.get("Total Workload Tokens (32 Tasks)") != "75248":
            errors.append("baseline_comparison_table.csv: LASR k=2 tokens mismatch (expected 75248)")
        if not k2_row or "22.1%" not in k2_row.get("Net Workload Savings %", ""):
            errors.append("baseline_comparison_table.csv: LASR k=2 savings mismatch (expected 22.1%)")
            
        lg_row = rows.get("LangGraph Stateful Accumulation Pattern")
        if not lg_row or lg_row.get("Total Workload Tokens (32 Tasks)") != "103895":
            errors.append("baseline_comparison_table.csv: LangGraph tokens mismatch (expected 103895)")

    # 6. Check baseline_comparison_snapshot.json
    snap_path = workspace / "version_2" / "baseline_comparison_snapshot.json"
    if not snap_path.exists():
        errors.append(f"Missing {snap_path}")
    else:
        with open(snap_path, "r", encoding="utf-8") as f:
            snap_data = json.load(f)
        snap_rows = {r["Architecture / Arm"]: r for r in snap_data}
        if "Full Schema (Draft 2020-12)" not in snap_rows or snap_rows["Full Schema (Draft 2020-12)"]["Total Workload Tokens (32 Tasks)"] != "96629":
            errors.append("baseline_comparison_snapshot.json: Full schema tokens mismatch")
        if "LASR-MCP (k=2 Reactive Recovery)" not in snap_rows or snap_rows["LASR-MCP (k=2 Reactive Recovery)"]["Total Workload Tokens (32 Tasks)"] != "75248":
            errors.append("baseline_comparison_snapshot.json: LASR k=2 tokens mismatch")

    # 7. Check Table 1 LaTeX
    t1_path = workspace / "version_2" / "paper_v2" / "tables" / "table1_systems_evaluation.tex"
    if not t1_path.exists():
        errors.append(f"Missing {t1_path}")
    else:
        t1_text = t1_path.read_text(encoding="utf-8")
        if "96,629" not in t1_text or "75,248" not in t1_text or "77,140" not in t1_text:
            errors.append("table1_systems_evaluation.tex: Primary token totals mismatch")
        if "2913.2" not in t1_text or "2351.5" not in t1_text:
            errors.append("table1_systems_evaluation.tex: Mean TTS mismatch")
        if "31.3\\%" not in t1_text:
            errors.append("table1_systems_evaluation.tex: First-pass 31.3% (half-up) missing")

    # 8. Check Table 2 LaTeX
    t2_path = workspace / "version_2" / "paper_v2" / "tables" / "table2_paired_bootstrap.tex"
    if not t2_path.exists():
        errors.append(f"Missing {t2_path}")
    else:
        t2_text = t2_path.read_text(encoding="utf-8")
        if "LASR Reactive ($k=1$) vs Full" not in t2_text or "LASR Reactive ($k=2$) vs Full" not in t2_text:
            errors.append("table2_paired_bootstrap.tex: Row labels must unambiguously specify contrast against Full")
        if "-19,489" not in t2_text or "-21,381" not in t2_text:
            errors.append("table2_paired_bootstrap.tex: Exact workload token differences missing")

    # 9. Check Table 3 LaTeX
    t3_path = workspace / "version_2" / "paper_v2" / "tables" / "table3_cluster_breakdown.tex"
    if not t3_path.exists():
        errors.append(f"Missing {t3_path}")
    else:
        t3_text = t3_path.read_text(encoding="utf-8")
        if "Observed Lift" not in t3_text:
            errors.append("table3_cluster_breakdown.tex: Must use 'Observed Lift' label")

    # 10. Check Table 4 LaTeX
    t4_path = workspace / "version_2" / "paper_v2" / "tables" / "table4_cross_schema.tex"
    if not t4_path.exists():
        errors.append(f"Missing {t4_path}")
    else:
        t4_text = t4_path.read_text(encoding="utf-8")
        if "54,657" not in t4_text or "42,369" not in t4_text:
            errors.append("table4_cross_schema.tex: Note must cite 54,657 -> 42,369 pooled tokens")
        if "66,720" in t4_text or "51,708" in t4_text:
            errors.append("table4_cross_schema.tex: Unreconciled legacy token counts found")
        if "316.8" not in t4_text:
            errors.append("table4_cross_schema.tex: Macro invariant floor 316.8 missing")
        if "361.3" not in t4_text:
            errors.append("table4_cross_schema.tex: Mean initial S0 (361.3) missing")
        if "553.3" not in t4_text:
            errors.append("table4_cross_schema.tex: Macro full schema size (553.3) missing")
        if "22.3\\%" not in t4_text:
            errors.append("table4_cross_schema.tex: Four-domain macro savings (22.3%) missing")
        if "22.5\\%" not in t4_text:
            errors.append("table4_cross_schema.tex: Pooled savings (22.5%) missing")

    # 11. Check Section 04 Results LaTeX
    sec4_path = workspace / "version_2" / "paper_v2" / "sections" / "04_results.tex"
    if not sec4_path.exists():
        errors.append(f"Missing {sec4_path}")
    else:
        sec4_text = sec4_path.read_text(encoding="utf-8")
        if "3,407.1" not in sec4_text or "0.0201" not in sec4_text or "0.00059\\%" not in sec4_text:
            errors.append("04_results.tex: Latency hierarchy or ratio mismatch")
        if "+0.613" not in sec4_text and "+0.6125" not in sec4_text:
            errors.append("04_results.tex: H1 delta (+0.613) missing")
        if "10,000" not in sec4_text:
            errors.append("04_results.tex: H1 B=10,000 bootstrap replications missing")

    # 12. Check Section 05 Cross-Schema Results LaTeX
    sec5_path = workspace / "version_2" / "paper_v2" / "sections" / "05_cross_schema_results.tex"
    if not sec5_path.exists():
        errors.append(f"Missing {sec5_path}")
    else:
        sec5_text = sec5_path.read_text(encoding="utf-8")
        if "22.3\\%" not in sec5_text:
            errors.append("05_cross_schema_results.tex: Four-domain macro mean 22.3% missing")
        if "22.7\\%" not in sec5_text:
            errors.append("05_cross_schema_results.tex: Three-domain macro mean 22.7% missing")
        if "22.5\\%" not in sec5_text:
            errors.append("05_cross_schema_results.tex: Pooled token reduction 22.5% missing")

    # 13. Check README_V2.md
    readme_path = workspace / "version_2" / "README_V2.md"
    if not readme_path.exists():
        errors.append(f"Missing {readme_path}")
    else:
        rm_text = readme_path.read_text(encoding="utf-8")
        if "75,248" not in rm_text or "96,629" not in rm_text:
            errors.append("README_V2.md: Primary workload token totals missing")
        if "file:///c:" in rm_text or "file:///C:" in rm_text:
            errors.append("README_V2.md: Nonportable absolute file URI links detected")
        if "baseline_trajectories.json" in rm_text:
            errors.append("README_V2.md: Stale reference to baseline_trajectories.json (must use baseline_comparison_snapshot.json)")

    return (len(errors) == 0, errors)

# Backward-compatible alias
validate_all_targets = audit_check

def regenerate_canonical_metrics(workspace: Path) -> Tuple[bool, str]:
    """
    Operator-triggered generation command.
    Derives canonical metrics from raw evidence and writes version_2/canonical_metrics.json.
    Reports changes relative to existing artifact if present.
    """
    print("[REGENERATE] Computing canonical metrics from raw pinned sources...")
    new_metrics = derive_all_canonical_metrics(workspace)
    
    out_path = workspace / "version_2" / "canonical_metrics.json"
    diff_report = []
    
    if out_path.exists():
        try:
            with open(out_path, "r", encoding="utf-8") as f:
                old_metrics = json.load(f)
            # Compare top-level keys
            for k in new_metrics:
                if k not in old_metrics:
                    diff_report.append(f"Added top-level section: {k}")
                elif new_metrics[k] != old_metrics[k]:
                    diff_report.append(f"Updated section: {k}")
        except Exception as e:
            diff_report.append(f"Could not parse existing artifact for diff: {e}")
    else:
        diff_report.append("Creating new canonical_metrics.json artifact")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(new_metrics, f, indent=2)
        
    print(f"[REGENERATE] Wrote {out_path.name} successfully.")
    diff_str = "\n".join(f"  - {d}" for d in diff_report) if diff_report else "  (No differences detected)"
    print(f"[REGENERATE] Diff report:\n{diff_str}")
    return True, diff_str

def test_regression_behavior(workspace: Path):
    print("[REGRESSION TEST] Testing that tampering with reported table values triggers validation failure...")
    csv_path = workspace / "version_2" / "baseline_comparison_table.csv"
    orig_content = csv_path.read_text(encoding="utf-8")
    try:
        tampered_content = orig_content.replace("75248", "99999")
        csv_path.write_text(tampered_content, encoding="utf-8")
        passed, errors = audit_check(workspace)
        if passed:
            raise AssertionError("Regression test FAILED: Tampered token total in CSV did not trigger error!")
        print(f"[REGRESSION TEST] Success: Tampered CSV value correctly caught: {errors}")
    finally:
        csv_path.write_text(orig_content, encoding="utf-8")
        print("[REGRESSION TEST] Original baseline table restored.")
        
    passed, errors = audit_check(workspace)
    print(f"[REGRESSION TEST] Post-restoration validation passed: {passed}")
    return True

def main():
    parser = argparse.ArgumentParser(description="Canonical Metric Reconciliation & Consistency Validator")
    parser.add_argument("--check", action="store_true", default=True, help="Run pure read-only audit check (default)")
    parser.add_argument("--regenerate", action="store_true", help="Explicitly regenerate canonical_metrics.json from evidence")
    parser.add_argument("--test-regression", action="store_true", help="Run regression test on tampering detection")
    args = parser.parse_args()
    
    if args.regenerate:
        success, report = regenerate_canonical_metrics(WORKSPACE)
        if not success:
            sys.exit(1)
        passed, errors = audit_check(WORKSPACE)
        if not passed:
            print("[WARNING] Post-regeneration audit found discrepancies:")
            for e in errors:
                print(f"  - {e}")
            sys.exit(1)
        else:
            print("[SUCCESS] Canonical metrics regenerated and audit checks passed!")
    elif args.test_regression:
        test_regression_behavior(WORKSPACE)
    else:
        passed, errors = audit_check(WORKSPACE)
        if not passed:
            print("[ERROR] Canonical audit check failed with findings:")
            for e in errors:
                print(f"  - {e}")
            sys.exit(1)
        else:
            print("[SUCCESS] Pure read-only canonical audit passed! All targets match canonical evidence.")

if __name__ == "__main__":
    main()
