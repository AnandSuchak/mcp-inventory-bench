#!/usr/bin/env python3
"""
Comprehensive Verifier Regression & Failure Injection Test Suite (Version 2.0.3)
Project: mcp-inventory-bench / Version 2.0.3
Author: Anand S. Suchak

Executes exhaustive failure injection and negative tests across all validation boundaries:
1. Manifest Security: Traversal ('..'), absolute paths, duplicate entries, altered hashes.
2. Manifest Completeness: Omitting required sibling files (e.g. metadata.json) is rejected.
3. Archive Validator: Omissions, nested zips, stale Version 2.0.2 in-package attestations.
4. Metric Consistency: Tampered CSV table values caught by reconciler.
5. Table IV Integrity: Tampered cross-schema table metrics caught.
6. Stale Derived Summary: Stale summary files detected against raw evidence.
7. Retrieval Outputs: Tampered retrieval JSON or CSV curves caught.
8. Latency Robustness: Non-finite, NaN, and boolean latency values strictly rejected.
9. Benchmark Task Matching: Task-set mismatches between evaluation arms rejected.
10. Missing Packager: Execution without create_audit_zip.py yields failing Check 9 and structured certificate.
11. Dependency Preflight: Subprocess without dependencies yields structured BLOCKED certificate and nonzero exit.
"""

import sys
import os
import json
import shutil
import tempfile
import zipfile
import subprocess
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parent.parent
if str(WORKSPACE) not in sys.path:
    sys.path.insert(0, str(WORKSPACE))

from create_audit_zip import validate_audit_archive
from version_2.verify_version_2_integrity import parse_and_validate_manifest
from version_2.reconcile_canonical_metrics import audit_check

def run_test(name: str, fn) -> bool:
    print(f"--> Running test: {name}...")
    try:
        fn()
        print(f"    [PASS] {name}")
        return True
    except Exception as exc:
        print(f"    [FAIL] {name}: {exc}")
        return False

def test_manifest_path_traversal():
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        dummy_file = tdp / "dummy.txt"
        dummy_file.write_text("hello", encoding="utf-8")
        
        # Test '..' traversal
        man_traversal = tdp / "MANIFEST.sha256"
        man_traversal.write_text("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824 ../outside.txt\n", encoding="utf-8")
        ok, msg, _ = parse_and_validate_manifest(man_traversal)
        assert not ok, "Manifest parser accepted directory traversal '..'!"
        assert "prohibited" in msg or "traversal" in msg

        # Test absolute path
        man_abs = tdp / "MANIFEST.sha256"
        man_abs.write_text("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824 /dummy.txt\n", encoding="utf-8")
        ok, msg, _ = parse_and_validate_manifest(man_abs)
        assert not ok, "Manifest parser accepted absolute path!"

def test_manifest_duplicate_entries():
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        dummy_file = tdp / "dummy.txt"
        dummy_file.write_text("hello", encoding="utf-8")
        h = "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
        
        man = tdp / "MANIFEST.sha256"
        man.write_text(f"{h} dummy.txt\n{h} dummy.txt\n", encoding="utf-8")
        ok, msg, _ = parse_and_validate_manifest(man)
        assert not ok, "Manifest parser accepted duplicate entry!"
        assert "Duplicate" in msg

def test_manifest_corrupted_hash():
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        dummy_file = tdp / "dummy.txt"
        dummy_file.write_text("hello", encoding="utf-8")
        bad_h = "1cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
        man = tdp / "MANIFEST.sha256"
        man.write_text(f"{bad_h} dummy.txt\n", encoding="utf-8")
        ok, msg, _ = parse_and_validate_manifest(man)
        assert not ok, "Manifest parser accepted mismatched hash!"
        assert "mismatch" in msg

def test_manifest_missing_metadata_entry():
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        (tdp / "invariant_optimization_summary.json").write_text("{}", encoding="utf-8")
        (tdp / "metadata.json").write_text("{}", encoding="utf-8")
        h1 = "44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a"
        
        # Manifest lists only 1 file
        man = tdp / "MANIFEST.sha256"
        man.write_text(f"{h1} invariant_optimization_summary.json\n", encoding="utf-8")
        expected = {"invariant_optimization_summary.json", "metadata.json"}
        ok, msg, _ = parse_and_validate_manifest(man, expected_files=expected)
        assert not ok, "Manifest parser accepted manifest missing metadata.json!"
        assert "missing expected payload entries" in msg

def test_archive_validator_omission():
    with tempfile.TemporaryDirectory() as td:
        zip_path = Path(td) / "test_missing.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("create_audit_zip.py", "print('hello')")
        ok, msg, stats = validate_audit_archive(zip_path)
        assert not ok, "Validator accepted archive missing required files!"
        assert "missing" in msg

def test_archive_validator_nested_zip():
    with tempfile.TemporaryDirectory() as td:
        zip_path = Path(td) / "test_nested.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("create_audit_zip.py", "print('hello')")
            zf.writestr("nested.zip", "PK...")
        ok, msg, stats = validate_audit_archive(zip_path)
        assert not ok, "Validator accepted archive with nested zip!"
        assert "nested" in msg.lower()

def test_archive_validator_stale_attestation():
    with tempfile.TemporaryDirectory() as td:
        zip_path = Path(td) / "test_stale_att.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("create_audit_zip.py", "print('hello')")
            zf.writestr("version_2/release_attestation_v2.0.2.json", "{}")
        ok, msg, stats = validate_audit_archive(zip_path)
        assert not ok, "Validator accepted archive containing stale 2.0.2 attestation!"
        assert "stale" in msg.lower()

def test_table_metric_tampering():
    csv_path = WORKSPACE / "version_2" / "baseline_comparison_table.csv"
    orig_content = csv_path.read_text(encoding="utf-8")
    try:
        csv_path.write_text(orig_content.replace("75248", "99999"), encoding="utf-8")
        ok, errors = audit_check(WORKSPACE)
        assert not ok, "Reconciler failed to catch tampered token metric!"
    finally:
        csv_path.write_text(orig_content, encoding="utf-8")
    
    ok, errors = audit_check(WORKSPACE)
    assert ok, f"Restored table failed validation: {errors}"

def test_table4_tampering():
    t4_path = WORKSPACE / "version_2" / "paper_v2" / "tables" / "table4_cross_schema.tex"
    orig_content = t4_path.read_text(encoding="utf-8")
    try:
        t4_path.write_text(orig_content.replace("316.8", "999.9"), encoding="utf-8")
        ok, errors = audit_check(WORKSPACE)
        assert not ok, "Reconciler failed to catch tampered Table IV metric!"
    finally:
        t4_path.write_text(orig_content, encoding="utf-8")

def test_stale_derived_summary():
    cs_path = WORKSPACE / "version_2" / "cross_schema_derived_summary.json"
    orig_content = cs_path.read_text(encoding="utf-8")
    try:
        cs_data = json.loads(orig_content)
        cs_data["pooled_workload_aggregate"]["pooled_workload_savings_pct"] = 99.9
        cs_path.write_text(json.dumps(cs_data), encoding="utf-8")
        ok, errors = audit_check(WORKSPACE)
        assert not ok, "Audit check failed to detect stale/tampered cross_schema_derived_summary.json!"
    finally:
        cs_path.write_text(orig_content, encoding="utf-8")

def test_latency_non_finite_rejection():
    from version_2.reconcile_canonical_metrics import derive_latencies
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        # Create cache dir with a boolean/NaN latency file
        cache_dir = tdp / "datasets" / "cache"
        cache_dir.mkdir(parents=True)
        bad_trace = cache_dir / "trace_bad.json"
        bad_trace.write_text(json.dumps({"lat": True}), encoding="utf-8")
        try:
            derive_latencies(tdp)
            assert False, "derive_latencies accepted boolean latency!"
        except Exception:
            pass

def test_task_set_mismatch():
    from version_2.reconcile_canonical_metrics import derive_primary_benchmark
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        raw_dir = tdp / "datasets" / "frozen_benchmark_n32"
        raw_dir.mkdir(parents=True)
        raw_file = raw_dir / "invariant_optimization_summary.json"
        # Create mismatched task records
        fake_data = {
            "systems_benchmark": {
                "full": {"records": [{"task_id": f"T{i}", "total_tokens_consumed": 100, "attempts": [{"tokens": 100}]} for i in range(32)]},
                "ci_k1_reactive": {"records": [{"task_id": f"T{i}", "total_tokens_consumed": 80, "attempts": [{"tokens": 80}]} for i in range(32)]},
                "ci_k2_reactive": {"records": [{"task_id": f"DIFF_{i}", "total_tokens_consumed": 75, "attempts": [{"tokens": 75}]} for i in range(32)]},
                "ci_k1_static": {"records": [{"task_id": f"T{i}", "total_tokens_consumed": 85, "attempts": [{"tokens": 85}]} for i in range(32)]},
                "ci_k0": {"records": [{"task_id": f"T{i}", "total_tokens_consumed": 85, "attempts": [{"tokens": 85}]} for i in range(32)]},
                "oracle_reactive": {"records": [{"task_id": f"T{i}", "total_tokens_consumed": 75, "attempts": [{"tokens": 75}]} for i in range(32)]}
            }
        }
        raw_file.write_text(json.dumps(fake_data), encoding="utf-8")
        try:
            derive_primary_benchmark(tdp)
            assert False, "derive_primary_benchmark accepted mismatched task IDs!"
        except ValueError as ve:
            assert "Task ID mismatch" in str(ve)

def test_missing_packager_behavior():
    with tempfile.TemporaryDirectory() as td:
        dest = Path(td)
        shutil.copytree(str(WORKSPACE / "version_2"), str(dest / "version_2"))
        shutil.copytree(str(WORKSPACE / "datasets"), str(dest / "datasets"))
        shutil.copy(str(WORKSPACE / "requirements-audit.txt"), str(dest / "requirements-audit.txt"))
        cert_path = dest / "version_2" / "verification_audit_certificate.json"
        if cert_path.exists():
            cert_path.unlink()

        verifier = dest / "version_2" / "verify_version_2_integrity.py"
        proc = subprocess.run(
            [sys.executable, str(verifier), "--stage", "missing_packager_test"],
            cwd=str(dest),
            capture_output=True,
            text=True
        )
        assert proc.returncode != 0, f"Verifier exited 0 when create_audit_zip.py was absent! stdout: {proc.stdout}"
        
        cert_path = dest / "version_2" / "verification_audit_certificate.json"
        assert cert_path.exists(), "Verifier failed to generate certificate on packager omission!"
        
        cert = json.loads(cert_path.read_text(encoding="utf-8"))
        assert cert.get("status") == "CHECKS_FAILED", f"Certificate status was {cert.get('status')}"
        c9 = [c for c in cert.get("checks", []) if "Packaging" in c.get("check", "")]
        assert c9 and not c9[0].get("passed"), "Check 9 was marked passed despite missing packager!"

def main():
    print("=" * 80)
    print("RUNNING LASR-MCP COMPREHENSIVE VERIFIER REGRESSION SUITE (VERSION 2.0.3)")
    print("=" * 80)
    
    tests = [
        ("Manifest Directory Traversal Rejection ('..' & absolute)", test_manifest_path_traversal),
        ("Manifest Duplicate Entry Rejection", test_manifest_duplicate_entries),
        ("Manifest Corrupted Hash Detection", test_manifest_corrupted_hash),
        ("Manifest Missing Sibling Metadata Rejection", test_manifest_missing_metadata_entry),
        ("Archive Validator Required Path Omission Rejection", test_archive_validator_omission),
        ("Archive Validator Nested ZIP Rejection", test_archive_validator_nested_zip),
        ("Archive Validator Stale In-Package Attestation Rejection", test_archive_validator_stale_attestation),
        ("Canonical Table Metric Tampering Detection", test_table_metric_tampering),
        ("Table IV Invariant Floor Tampering Detection", test_table4_tampering),
        ("Stale Derived Summary Detection", test_stale_derived_summary),
        ("Non-Finite & Boolean Latency Value Rejection", test_latency_non_finite_rejection),
        ("Multi-Arm Task ID Mismatch Rejection", test_task_set_mismatch),
        ("Missing Packager Subprocess & Structured Certificate Failure", test_missing_packager_behavior)
    ]
    
    passed_count = sum(1 for name, fn in tests if run_test(name, fn))
    print("=" * 80)
    print(f"REGRESSION SUITE COMPLETED: {passed_count}/{len(tests)} TESTS PASSED")
    print("=" * 80)
    if passed_count != len(tests):
        sys.exit(1)

if __name__ == "__main__":
    main()
