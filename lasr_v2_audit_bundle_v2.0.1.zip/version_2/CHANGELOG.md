# Changelog: LASR-MCP Version 2

All notable changes to the LASR-MCP Version 2 benchmark, audit tools, and manuscripts are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to Semantic Versioning for its release packaging. Note that release versions track software/audit releases and are kept separate from scientific manuscript version designations.

---

## [2.0.1] - 2026-10-16

### Fixed
- **Reproducible Archive Verification Defect (Check 9)**: Resolved an issue where running `verify_version_2_integrity.py` inside a freshly extracted release archive crashed with an uncaught `FileNotFoundError` because `create_audit_zip.py` had not been included in the root of the generated zip bundle.
- **Archive Self-Inclusion**: Enhanced `create_audit_zip.py` to explicitly exclude all `*.zip` files and temporary extraction directories (`temp_*`, `test_*`, `tmp/`), preventing accidental recursive zip-in-zip bloat.
- **Graceful Error Handling in Verifier**: Updated `version_2/verify_version_2_integrity.py` so that missing files across all 9 checks produce structured failure reports (`passed: false` with actionable diagnostic messages) rather than unhandled Python exceptions.
- **Unconditional Audit Certificate Generation**: Guaranteed that `version_2/verification_audit_certificate.json` is exported even when checks fail, recording exact passed/failed check counts and failure details.
- **Dynamic Runtime Timestamp**: Replaced hardcoded historical timestamp with runtime ISO 8601 timestamp (`datetime.now(timezone.utc).astimezone().isoformat()`).

### Changed Files
1. `create_audit_zip.py`:
   - Added `create_audit_zip.py` to `include_paths` with root arcname.
   - Added `*.zip` filtering and temporary directory exclusion during walk.
   - Added `--out` command line argument, defaulting to `lasr_v2_audit_bundle_v2.0.1.zip`.
2. `version_2/verify_version_2_integrity.py`:
   - Updated Check 9 to verify existence of `create_audit_zip.py` at workspace root, inclusion of all 5 source trees (`version_2`, `datasets/frozen_benchmark_n32`, `datasets/cross_schema_validation`, `datasets/cache`, `trace`), self-inclusion, and `.zip` exclusion.
   - Guarded Checks 1–8 with file existence validations and descriptive error details.
   - Replaced static timestamp with dynamic runtime timestamp.
   - Added release version tag `2.0.1` to exported certificate.
3. `version_2/README_V2.md`:
   - Documented Version 2.0.1 controlled patch and updated file inventory.
4. `version_2/CHANGELOG.md`:
   - Created this changelog documenting 2.0.0 baseline and 2.0.1 patch.
5. `version_2/RELEASE_NOTES_2.0.1.md`:
   - Published release notes for Version 2.0.1.

### Tests Performed
1. **Missing File Robustness Test**: Ran verifier with `create_audit_zip.py` temporarily absent. Verified that the verifier finished cleanly without unhandled exceptions, reported Check 9 as `[FAIL]`, wrote a failure certificate with status `"CHECKS_FAILED"`, and exited with code 1.
2. **Packaged Script Test**: Ran verifier with `create_audit_zip.py` restored. Verified all 9 checks pass with 100% precision and exit code 0.
3. **Archive Builder Test**: Generated `lasr_v2_audit_bundle_v2.0.1.zip`. Confirmed it packaged `create_audit_zip.py` at the root and contained no recursive `*.zip` archives.
4. **Isolated Extraction & Independent Audit**: Extracted `lasr_v2_audit_bundle_v2.0.1.zip` into a clean temporary directory. Ran `python version_2/verify_version_2_integrity.py` from that clean extracted root. Confirmed all 9 checks pass with 100% precision.
5. **Toolchain Compilation Check**: Probed host environment for LaTeX compilers (`pdflatex`, `latexmk`). Recorded exact status (`BLOCKED: toolchain not installed on host PATH`).

---

## [2.0.0] - 2026-10-16

### Baseline Snapshot
- **Baseline Archive**: `lasr_v2_audit_bundle.zip` (SHA-256: `36cf1def3de7bde589c02839b26ed10ac0fb2ec923eaffb46282e96e43fd00f3`).
- **Mathematical Bound Correction**: Proved finite monotonic recovery bound $K \le M - |A_0|$ in `version_2/formal_termination_proof.tex` and `version_2/paper_v2/sections/02_system_architecture.tex`. Disproved heuristic depth bound $K \le D$ via sibling-leaf counterexample.
- **LaTeX Proof Environment**: Defined `\begin{IEEEproof}` environments compliant with `IEEEtran.cls`.
- **Table Formatting Fixes**: Resolved Table V single-column overflow using `\resizebox{\columnwidth}{!}` and replaced cross-schema pooled row schema sizes with `-- & --` in Table IV.
- **Retrieval Baselines Decoupling**: Recomputed Lexical TF-IDF Macro Recall@2 (12.5%, 75.0% zero-hits) and Inductive LSA SVD-16 Macro Recall@2 (14.06%, 71.9% zero-hits). Marked retrieval rows in Table V as `NOT MEASURED (Retrieval-Only)` to prevent conflation with end-to-end validator execution.
- **LangGraph Counterfactual Model**: Characterized LangGraph state accumulation as a trace-derived counterfactual token model (+45 tok compiler context, 103,895 tokens, +7.52% overhead / -7.52% net savings).
- **Latency Benchmarking**: Measured local in-tree AST recomposition latency across 1,000 iterations ($p_{50} = 20.1\ \mu\text{s}$) against 556 empirical API response traces ($p_{50} = 3,407.1\text{ ms}$), showing an overhead ratio of $0.00059\%$.
- **Version 1 Immutability**: All original Version 1 files (`paper/main.pdf`, `paper/`, `datasets/`, `trace/`, `README.md`) preserved 100% untouched.
