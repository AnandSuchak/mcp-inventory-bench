#!/usr/bin/env python3
"""
Comprehensive Audit & Integrity Verification Suite (Version 2.0.1)
Project: mcp-inventory-bench / Version 2.0.1
Author: Anand S. Suchak

Performs deep, independent programmatic recomputation across all Version 2.0 research artifacts:
1. Cryptographic Provenance (Frozen Benchmark SHA-256 + Cross-Schema Validation Manifests)
2. Raw Attempt-by-Attempt Token Accounting & Dual-Metric Savings Recomputation
3. Empirical Request Latency directly recomputed by parsing all 556 files in datasets/cache/
4. Retrieval Baselines directly recomputed from full_schema.json & benchmark_tasks_n32.json:
   - Lexical TF-IDF Macro Recall@2 (12.50%) & Zero-Recall count (24/32 = 75.0%)
   - Inductive Latent Semantic Analysis SVD-16 Macro Recall@2 (14.06%) & Zero-Recall count (23/32 = 71.88%)
5. LangGraph Counterfactual Token Model (+45 tok compiler context, 103,895 tokens, -7.52% net savings)
6. Formal Mathematical Theorem & Counterexample Consistency (K <= M - |A0|, IEEEproof, Sibling Leaf counterexample)
7. Manuscript Source & Table Layout Integrity (Table V column resize, Table IV pooled row dashes, NOT MEASURED retrieval rows)
8. Audit Archive Packaging Verification (datasets/cross_schema_validation, create_audit_zip.py self-inclusion, recursive zip exclusion)

Outputs full audit results to stdout and saves version_2/verification_audit_certificate.json with a dynamic runtime timestamp.
"""

import sys
import os
import json
import glob
import re
import math
import hashlib
import statistics
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Set
from collections import Counter

WORKSPACE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE))

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
import numpy as np

from version_2.lasr_trace_audit import schema_chunks, tfidf_vectors, cosine_sparse

def compute_sha256(filepath: Path) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def percentile(vals: List[float], p: float) -> float:
    if not vals:
        return 0.0
    sorted_vals = sorted(vals)
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    pos = (len(sorted_vals) - 1) * p
    lo, hi = math.floor(pos), math.ceil(pos)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (pos - lo)

def verify_all() -> bool:
    checks = []
    runtime_timestamp = datetime.now(timezone.utc).astimezone().isoformat()
    
    print("=" * 80)
    print("LASR-MCP VERSION 2.0.1: DEEP PROGRAMMATIC INTEGRITY & ARITHMETIC AUDIT")
    print(f"Timestamp: {runtime_timestamp}")
    print("=" * 80)

    # --------------------------------------------------------------------------
    # Check 1: Cryptographic Provenance Verification (Frozen Benchmark & Cross-Schema)
    # --------------------------------------------------------------------------
    frozen_file = WORKSPACE / "datasets" / "frozen_benchmark_n32" / "invariant_optimization_summary.json"
    manifest_file = WORKSPACE / "datasets" / "frozen_benchmark_n32" / "MANIFEST.sha256"
    cross_file = WORKSPACE / "datasets" / "cross_schema_validation" / "cross_schema_results.json"
    cross_manifest = WORKSPACE / "datasets" / "cross_schema_validation" / "MANIFEST.sha256"

    if not frozen_file.exists():
        checks.append({
            "check": "Cryptographic SHA-256 Provenance & Manifest Integrity",
            "passed": False,
            "details": f"FAIL: Primary frozen benchmark file missing at {frozen_file}"
        })
        print(f"[FAIL] 1. Cryptographic Provenance: Missing {frozen_file}")
    elif not cross_file.exists():
        checks.append({
            "check": "Cryptographic SHA-256 Provenance & Manifest Integrity",
            "passed": False,
            "details": f"FAIL: Cross-schema validation file missing at {cross_file}"
        })
        print(f"[FAIL] 1. Cryptographic Provenance: Missing {cross_file}")
    else:
        exp_frozen_hash = "78c2c88ed5128e0f296fa29e0c258589b516f3adb14b0b8da491fa73bc3ffc11"
        act_frozen_hash = compute_sha256(frozen_file)
        frozen_ok = (act_frozen_hash == exp_frozen_hash)

        exp_cross_hash = "b3d57636f9834ff536204acfe88454c9620228bb67705f1b3caa40e0d562302a"
        act_cross_hash = compute_sha256(cross_file)
        cross_ok = (act_cross_hash == exp_cross_hash)

        # Verify cross-schema dataset contents: 64 records
        with open(cross_file, "r", encoding="utf-8") as f:
            cross_data = json.load(f)
        cross_recs = cross_data.get("records", [])
        cross_recs_ok = (len(cross_recs) == 64)

        c1_passed = frozen_ok and cross_ok and cross_recs_ok
        checks.append({
            "check": "Cryptographic SHA-256 Provenance & Manifest Integrity",
            "passed": c1_passed,
            "details": f"Frozen hash match={frozen_ok}, Cross-schema hash match={cross_ok}, Cross-schema records count={len(cross_recs)} (exp 64)"
        })
        print(f"[{'PASS' if c1_passed else 'FAIL'}] 1. Cryptographic Provenance: Frozen Benchmark & Cross-Schema Hashes Match Manifests (64 records)")

    # --------------------------------------------------------------------------
    # Check 2: Raw Attempt-by-Attempt Token Accounting Recomputation
    # --------------------------------------------------------------------------
    if not frozen_file.exists():
        checks.append({
            "check": "Raw Attempt Token Sums & Structural Success Recomputation",
            "passed": False,
            "details": "FAIL: Frozen benchmark file missing"
        })
        print("[FAIL] 2. Raw Token Recomputation: Frozen benchmark missing")
        full_recs, k2_recs, k1_recs = [], [], []
        full_sum, k2_sum, k1_sum = 0, 0, 0
    else:
        with open(frozen_file, "r", encoding="utf-8") as f:
            frozen_data = json.load(f)
        
        sb = frozen_data.get("systems_benchmark", {})
        full_recs = sb.get("full", {}).get("records", [])
        k2_recs = sb.get("ci_k2_reactive", {}).get("records", [])
        k1_recs = sb.get("ci_k1_reactive", {}).get("records", [])

        full_sum = sum(sum(a["tokens"] for a in r["attempts"]) for r in full_recs)
        k2_sum = sum(sum(a["tokens"] for a in r["attempts"]) for r in k2_recs)
        k1_sum = sum(sum(a["tokens"] for a in r["attempts"]) for r in k1_recs)

        full_successes = sum(1 for r in full_recs if r["final_structural_success"])
        k2_successes = sum(1 for r in k2_recs if r["final_structural_success"])
        k1_successes = sum(1 for r in k1_recs if r["final_structural_success"])

        c2_passed = (full_sum == 96629 and k2_sum == 75248 and k1_sum == 77140 and
                     full_successes == 30 and k2_successes == 32 and k1_successes == 32)
        checks.append({
            "check": "Raw Attempt Token Sums & Structural Success Recomputation",
            "passed": c2_passed,
            "details": f"Full={full_sum} tok ({full_successes}/32 succ), k2={k2_sum} tok ({k2_successes}/32 succ), k1={k1_sum} tok ({k1_successes}/32 succ)"
        })
        print(f"[{'PASS' if c2_passed else 'FAIL'}] 2. Raw Token Recomputation: Full={full_sum} (30/32), k2={k2_sum} (32/32), k1={k1_sum} (32/32)")

    # --------------------------------------------------------------------------
    # Check 3: Dual-Metric Token Savings Reconciliation (Workload vs. Conditional TTS)
    # --------------------------------------------------------------------------
    if not full_recs or not k2_recs or full_sum == 0:
        checks.append({
            "check": "Dual Metric Token Reconciliation (Workload vs. Conditional TTS)",
            "passed": False,
            "details": "FAIL: Benchmark records unavailable for dual-metric calculation"
        })
        print("[FAIL] 3. Dual Token Metrics: Benchmark records unavailable")
    else:
        workload_savings_k2 = ((full_sum - k2_sum) / full_sum) * 100.0 # 22.126% -> 22.1%
        workload_savings_k1 = ((full_sum - k1_sum) / full_sum) * 100.0 # 20.168% -> 20.2%
        
        # Conditional TTS calculation strictly over successful tasks
        full_tts_vals = [r["total_tokens_consumed"] for r in full_recs if r["final_structural_success"]]
        k2_tts_vals = [r["total_tokens_consumed"] for r in k2_recs if r["final_structural_success"]]
        
        full_mean_tts = statistics.mean(full_tts_vals)
        k2_mean_tts = statistics.mean(k2_tts_vals)
        tts_savings = ((full_mean_tts - k2_mean_tts) / full_mean_tts) * 100.0 # 19.28% -> 19.3%

        tts_ok = (abs(full_mean_tts - 2913.2) < 0.1 and abs(k2_mean_tts - 2351.5) < 0.1)
        savings_ok = (abs(workload_savings_k2 - 22.1) < 0.1 and abs(tts_savings - 19.3) < 0.1)

        c3_passed = tts_ok and savings_ok
        checks.append({
            "check": "Dual Metric Token Reconciliation (Workload vs. Conditional TTS)",
            "passed": c3_passed,
            "details": f"Workload Savings={workload_savings_k2:.2f}% (exp 22.1%), Conditional TTS Savings={tts_savings:.2f}% (exp 19.3%), Full TTS Mean={full_mean_tts:.1f}, k2 TTS Mean={k2_mean_tts:.1f}"
        })
        print(f"[{'PASS' if c3_passed else 'FAIL'}] 3. Dual Token Metrics: Workload Savings={workload_savings_k2:.2f}%, TTS Savings={tts_savings:.2f}%")

    # --------------------------------------------------------------------------
    # Check 4: Empirical Latency Recomputed from 556 Provider Execution Traces
    # --------------------------------------------------------------------------
    cache_files = glob.glob(str(WORKSPACE / "datasets" / "cache" / "*.json"))
    raw_latencies_ms = []
    for fpath in cache_files:
        try:
            with open(fpath, "r", encoding="utf-8") as fp:
                d = json.load(fp)
                if "lat" in d and isinstance(d["lat"], (int, float)):
                    raw_latencies_ms.append(float(d["lat"]))
        except Exception:
            pass

    csv_lat_file = WORKSPACE / "version_2" / "latency_benchmark_measurements.csv"
    ast_latencies_ms = []
    if csv_lat_file.exists():
        with open(csv_lat_file, "r", encoding="utf-8") as fp:
            for line in fp:
                parts = line.strip().split(",")
                if len(parts) >= 9 and parts[0].isdigit():
                    ast_latencies_ms.append(float(parts[8]))

    if len(raw_latencies_ms) != 556 or len(ast_latencies_ms) != 1000:
        c4_passed = False
        details = f"FAIL: Expected 556 cache traces (got {len(raw_latencies_ms)}) and 1000 AST runs (got {len(ast_latencies_ms)})"
    else:
        req_p50 = percentile(raw_latencies_ms, 0.50)
        req_p90 = percentile(raw_latencies_ms, 0.90)
        req_p99 = percentile(raw_latencies_ms, 0.99)
        ast_p50 = percentile(ast_latencies_ms, 0.50)
        ast_p99 = percentile(ast_latencies_ms, 0.99)
        overhead_ratio = (ast_p50 / req_p50) * 100.0

        c4_passed = (abs(req_p50 - 3407.1) < 2.0 and abs(req_p99 - 56708.5) < 2.0 and
                     abs(ast_p50 - 0.0201) < 0.005 and overhead_ratio < 0.001)
        details = (f"556 Cache traces: p50={req_p50:.1f}ms, p90={req_p90:.1f}ms, p99={req_p99:.1f}ms. "
                   f"1000 AST runs: p50={ast_p50*1000:.1f}us ({ast_p50:.4f}ms), Ratio={overhead_ratio:.5f}%")

    checks.append({
        "check": "Empirical Latency Hierarchy & AST Overhead Recomputation",
        "passed": c4_passed,
        "details": details
    })
    print(f"[{'PASS' if c4_passed else 'FAIL'}] 4. Empirical Latency: 556 Cache Traces p50={req_p50:.1f}ms, 1000 AST Runs p50={ast_p50*1000:.1f}us, AST Ratio={overhead_ratio:.5f}% (<0.001%)")

    # --------------------------------------------------------------------------
    # Check 5: Direct Recomputation of Retrieval Baselines (TF-IDF & Inductive LSA)
    # --------------------------------------------------------------------------
    schema_file = WORKSPACE / "version_2" / "full_schema.json"
    tasks_file = WORKSPACE / "version_2" / "benchmark_tasks_n32.json"

    if not schema_file.exists() or not tasks_file.exists():
        c5_passed = False
        details = f"FAIL: Missing schema ({schema_file.exists()}) or tasks ({tasks_file.exists()})"
    else:
        with open(schema_file, "r", encoding="utf-8") as f:
            full_schema_obj = json.load(f)
        with open(tasks_file, "r", encoding="utf-8") as f:
            tasks_obj = json.load(f)

        chunks = schema_chunks(full_schema_obj)
        chunk_texts = [f"{c['id']} {c['text']}" for c in chunks]
        task_queries = [t["query"] for t in tasks_obj]

        # A. Recompute Lexical TF-IDF Baseline
        corpus = [c["text"] for c in chunks] + task_queries
        lex_vecs = tfidf_vectors(corpus)
        chunk_lex_vecs = lex_vecs[:len(chunks)]
        task_lex_vecs = lex_vecs[len(chunks):]
        lex_recalls = []
        lex_zero_hits = 0
        for task, qvec in zip(tasks_obj, task_lex_vecs):
            ranked_idx = sorted(range(len(chunks)), key=lambda i: cosine_sparse(qvec, chunk_lex_vecs[i]), reverse=True)[:2]
            retrieved = {chunks[i]["id"] for i in ranked_idx}
            gold = set(task["target_constraints"])
            found = gold & retrieved
            rec = len(found) / len(gold) if gold else 0.0
            lex_recalls.append(rec)
            if len(found) == 0:
                lex_zero_hits += 1
        recomputed_lex_recall = statistics.mean(lex_recalls)

        # B. Recompute Inductive LSA SVD Baseline
        tfidf_ind = TfidfVectorizer(ngram_range=(1, 3), sublinear_tf=True, min_df=1)
        chunk_tfidf = tfidf_ind.fit_transform(chunk_texts)
        task_tfidf = tfidf_ind.transform(task_queries)

        n_comp = min(16, chunk_tfidf.shape[1] - 1)
        svd = TruncatedSVD(n_components=n_comp, random_state=42)
        chunk_emb = svd.fit_transform(chunk_tfidf)
        task_emb = svd.transform(task_tfidf)

        def cos_sim(v1, v2):
            n1, n2 = np.linalg.norm(v1), np.linalg.norm(v2)
            return float(np.dot(v1, v2) / (n1 * n2)) if (n1 > 0 and n2 > 0) else 0.0

        lsa_recalls = []
        lsa_zero_hits = 0
        for task, q_vec in zip(tasks_obj, task_emb):
            sims = [cos_sim(q_vec, c_vec) for c_vec in chunk_emb]
            ranked_idx = sorted(range(len(chunks)), key=lambda i: sims[i], reverse=True)[:2]
            retrieved = {chunks[i]["id"] for i in ranked_idx}
            gold = set(task["target_constraints"])
            found = gold & retrieved
            rec = len(found) / len(gold) if gold else 0.0
            lsa_recalls.append(rec)
            if len(found) == 0:
                lsa_zero_hits += 1
        recomputed_lsa_recall = statistics.mean(lsa_recalls)

        c5_passed = (abs(recomputed_lex_recall - 0.1250) < 0.001 and
                     lex_zero_hits == 24 and
                     abs(recomputed_lsa_recall - 0.1406) < 0.001 and
                     lsa_zero_hits == 23)
        details = (f"TF-IDF Recall@2={recomputed_lex_recall*100:.2f}% (zero-hits: {lex_zero_hits}/32 = {lex_zero_hits/32*100:.1f}%), "
                   f"LSA SVD Recall@2={recomputed_lsa_recall*100:.2f}% (zero-hits: {lsa_zero_hits}/32 = {lsa_zero_hits/32*100:.1f}%)")

    checks.append({
        "check": "Retrieval Baselines Direct Programmatic Recomputation",
        "passed": c5_passed,
        "details": details
    })
    print(f"[{'PASS' if c5_passed else 'FAIL'}] 5. Retrieval Baselines Recomputed: TF-IDF={recomputed_lex_recall*100:.1f}% ({lex_zero_hits}/32 zero-hits), LSA SVD={recomputed_lsa_recall*100:.1f}% ({lsa_zero_hits}/32 zero-hits)")

    # --------------------------------------------------------------------------
    # Check 6: LangGraph Counterfactual Model Audit
    # --------------------------------------------------------------------------
    lg_path = WORKSPACE / "version_2" / "langgraph_traces.json"
    if not lg_path.exists():
        c6_passed = False
        details = f"FAIL: LangGraph trace file missing at {lg_path}"
    else:
        with open(lg_path, "r", encoding="utf-8") as f:
            lg_data = json.load(f)
        act_lg_tokens = lg_data.get("total_workload_tokens", 0)

        lg_overhead = ((act_lg_tokens - full_sum) / full_sum) * 100.0 if full_sum else 0.0
        lg_lasr_savings = ((act_lg_tokens - k2_sum) / act_lg_tokens) * 100.0 if act_lg_tokens else 0.0

        c6_passed = (act_lg_tokens == 103895 and
                     abs(lg_overhead - 7.52) < 0.05 and
                     abs(lg_lasr_savings - 27.57) < 0.05)
        details = f"LangGraph Total={act_lg_tokens} tok (+{lg_overhead:.2f}% overhead vs Full -> -{lg_overhead:.2f}% savings; LASR k=2 vs LangGraph savings={lg_lasr_savings:.2f}%)"

    checks.append({
        "check": "LangGraph Counterfactual Model Token Overhead Audit",
        "passed": c6_passed,
        "details": details
    })
    print(f"[{'PASS' if c6_passed else 'FAIL'}] 6. LangGraph Model Audit: Total={act_lg_tokens} tok, Overhead=+{lg_overhead:.2f}% (-{lg_overhead:.2f}% net savings), LASR k=2 Savings={lg_lasr_savings:.2f}%")

    # --------------------------------------------------------------------------
    # Check 7: Formal Mathematical Theorem & Counterexample Integrity
    # --------------------------------------------------------------------------
    paper_sec2 = WORKSPACE / "version_2" / "paper_v2" / "sections" / "02_system_architecture.tex"
    proof_standalone = WORKSPACE / "version_2" / "formal_termination_proof.tex"
    
    if not paper_sec2.exists() or not proof_standalone.exists():
        c7_passed = False
        details = f"FAIL: Missing paper section 2 ({paper_sec2.exists()}) or standalone proof ({proof_standalone.exists()})"
    else:
        sec2_text = paper_sec2.read_text(encoding="utf-8")
        proof_text = proof_standalone.read_text(encoding="utf-8")

        has_cardinality = ("K \\le M - |A_0|" in sec2_text and "K \\le M - |A_0|" in proof_text)
        has_ieee_proof = ("\\begin{IEEEproof}" in sec2_text and "\\end{IEEEproof}" in sec2_text)
        has_counterexample = ("sibling leaf constraint" in sec2_text.lower() or "two sibling leaf" in sec2_text.lower() or "two independent constraints" in sec2_text.lower())
        rejects_depth = ("invalid" in sec2_text.lower() or "does not constrain" in sec2_text.lower())

        c7_passed = has_cardinality and has_ieee_proof and has_counterexample and rejects_depth
        details = f"Bound=K<=M-|A0| ({has_cardinality}), IEEEproof Environment ({has_ieee_proof}), Sibling Leaf Counterexample ({has_counterexample}), K<=D Rejected ({rejects_depth})"

    checks.append({
        "check": "Formal Mathematical Theorem & Counterexample Consistency",
        "passed": c7_passed,
        "details": details
    })
    print(f"[{'PASS' if c7_passed else 'FAIL'}] 7. Formal Proof: K<=M-|A0| Established with IEEEproof and Sibling Leaf Counterexample")

    # --------------------------------------------------------------------------
    # Check 8: Manuscript Source Layout & Table Integrity
    # --------------------------------------------------------------------------
    table4_path = WORKSPACE / "version_2" / "paper_v2" / "tables" / "table4_cross_schema.tex"
    results_path = WORKSPACE / "version_2" / "paper_v2" / "sections" / "04_results.tex"
    csv_table5 = WORKSPACE / "version_2" / "baseline_comparison_table.csv"

    if not table4_path.exists() or not results_path.exists() or not csv_table5.exists():
        c8_passed = False
        details = f"FAIL: Missing table 4 ({table4_path.exists()}), results ({results_path.exists()}), or csv ({csv_table5.exists()})"
    else:
        table4_text = table4_path.read_text(encoding="utf-8")
        results_text = results_path.read_text(encoding="utf-8")
        csv_text = csv_table5.read_text(encoding="utf-8")

        pooled_dashes = ("Pooled Workload Aggregate" in table4_text and "-- & --" in table4_text)
        table5_resize = ("\\resizebox{\\columnwidth}{!}" in results_text)
        reports_12_5 = ("12.5\\%" in results_text or "12.5%" in results_text)
        reports_14_1 = ("14.1\\%" in results_text or "14.1%" in results_text)
        reports_zero_hits = ("75.0\\%" in results_text and "71.9\\%" in results_text)
        sublinear_lsa = ("sublinear word 1-to-3-grams" in results_text)
        csv_retrieval_separated = ("NOT MEASURED (Retrieval-Only)" in csv_text)
        csv_counterfactual_labeled = ("Counterfactual Token Model" in csv_text or "Counterfactual Token-History Model" in csv_text)
        csv_sign_convention = ("-7.5% (Token Overhead)" in csv_text)

        c8_passed = (pooled_dashes and table5_resize and reports_12_5 and reports_14_1 and
                     reports_zero_hits and sublinear_lsa and csv_retrieval_separated and
                     csv_counterfactual_labeled and csv_sign_convention)
        details = (f"Table 4 dashes={pooled_dashes}, Table 5 resizebox={table5_resize}, "
                   f"Exact recall disclosed={reports_12_5 and reports_14_1}, Zero-hit counts={reports_zero_hits}, "
                   f"LSA sublinear text={sublinear_lsa}, CSV retrieval separated={csv_retrieval_separated}, "
                   f"Counterfactual labeled={csv_counterfactual_labeled}")

    checks.append({
        "check": "Manuscript Source Layout & Empirical Separation Integrity",
        "passed": c8_passed,
        "details": details
    })
    print(f"[{'PASS' if c8_passed else 'FAIL'}] 8. Manuscript Integrity: Table 4 Dashes, Table 5 Resizebox, Exact Recall & Zero-Hits Disclosed, CSV Separations Clear")

    # --------------------------------------------------------------------------
    # Check 9: Audit Archive Packaging Script Integrity & Reproducibility
    # --------------------------------------------------------------------------
    create_zip_path = WORKSPACE / "create_audit_zip.py"
    if not create_zip_path.exists():
        c9_passed = False
        details = (f"FAIL: Archive packaging script not found at expected workspace root: {create_zip_path}. "
                   "create_audit_zip.py must be present at workspace root to ensure reproducible audit bundling.")
    else:
        try:
            zip_script_text = create_zip_path.read_text(encoding="utf-8")
            includes_cross = ("datasets/cross_schema_validation" in zip_script_text)
            includes_v2 = ("version_2" in zip_script_text)
            includes_frozen = ("datasets/frozen_benchmark_n32" in zip_script_text)
            includes_cache = ("datasets/cache" in zip_script_text)
            includes_trace = ("trace" in zip_script_text)
            includes_self = ("create_audit_zip.py" in zip_script_text)
            excludes_zip = (".zip" in zip_script_text)

            c9_passed = bool(includes_cross and includes_v2 and includes_frozen and 
                             includes_cache and includes_trace and includes_self and excludes_zip)
            details = (f"cross_schema={includes_cross}, version_2={includes_v2}, "
                       f"frozen_bench={includes_frozen}, cache={includes_cache}, "
                       f"trace={includes_trace}, packager_root={includes_self}, "
                       f"excludes_zip={excludes_zip}")
        except Exception as exc:
            c9_passed = False
            details = f"FAIL: Error reading {create_zip_path}: {exc}"

    checks.append({
        "check": "Audit Archive Packaging Script Inclusions & Reproducibility",
        "passed": c9_passed,
        "details": details
    })
    print(f"[{'PASS' if c9_passed else 'FAIL'}] 9. Packaging Script: 5 Source Trees + Self-Packaging Confirmed in create_audit_zip.py")

    # --------------------------------------------------------------------------
    # Summary & Certificate Export
    # --------------------------------------------------------------------------
    all_passed = all(c["passed"] for c in checks)
    cert = {
        "audit_name": "LASR-MCP Version 2.0 Scientific Integrity & Verification Certificate",
        "release_version": "2.0.1",
        "status": "ALL_CHECKS_PASSED" if all_passed else "CHECKS_FAILED",
        "total_checks": len(checks),
        "passed_checks": sum(1 for c in checks if c["passed"]),
        "failed_checks": sum(1 for c in checks if not c["passed"]),
        "audit_timestamp": runtime_timestamp,
        "checks": checks
    }

    cert_path = WORKSPACE / "version_2" / "verification_audit_certificate.json"
    try:
        cert_path.parent.mkdir(parents=True, exist_ok=True)
        with open(cert_path, "w", encoding="utf-8") as f:
            json.dump(cert, f, indent=2)
    except Exception as exc:
        print(f"ERROR: Could not write certificate to {cert_path}: {exc}")

    print("=" * 80)
    if all_passed:
        print(f"ALL {len(checks)} VERIFICATION CHECKS PASSED WITH 100% MATHEMATICAL PRECISION!")
        print(f"Official Audit Certificate saved to {cert_path.name}")
    else:
        print(f"AUDIT FAILED: {cert['failed_checks']} of {len(checks)} checks failed. Review logs above.")
        print(f"Failure Certificate saved to {cert_path.name}")
    print("=" * 80)
    return all_passed

if __name__ == "__main__":
    success = verify_all()
    sys.exit(0 if success else 1)
