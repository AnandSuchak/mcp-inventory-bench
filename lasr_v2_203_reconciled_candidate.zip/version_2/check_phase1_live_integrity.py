#!/usr/bin/env python3
"""
Independent Checker for Phase 1 Live Benchmark Rerun Artifacts
Verifies:
1. Artifacts checksum integrity against run_manifest.json.
2. Raw attempt recomputation across all 6 arms and 32 tasks from invariant_optimization_summary.json.
3. Cache trace integrity and valid Gemini response IDs from live_rerun_cache_entries.zip.
4. Delta comparison consistency with frozen baseline.
"""

import sys
import os
import json
import csv
import zipfile
import hashlib
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parent.parent
PHASE1_DIR = WORKSPACE / "phase1_live_rerun_artifacts"
FROZEN_FILE = WORKSPACE / "datasets" / "frozen_benchmark_n32" / "invariant_optimization_summary.json"

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def verify_phase1_artifacts() -> bool:
    print("=" * 80)
    print("INDEPENDENT CHECKER: LASR-MCP PHASE 1 LIVE BENCHMARK ARTIFACTS")
    print("=" * 80)

    # 1. Manifest verification
    manifest_path = PHASE1_DIR / "run_manifest.json"
    if not manifest_path.exists():
        print(f"[FAIL] Missing manifest at {manifest_path}")
        return False

    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    print(f"[*] Run Window: {manifest.get('timestamp_start')} -> {manifest.get('timestamp_end')}")
    print(f"[*] Provider: {manifest.get('provider')} | Model: {manifest.get('model')}")
    print(f"[*] Elapsed: {manifest.get('elapsed_display')}")

    checksums = manifest.get("artifacts_checksums", {})
    all_checksums_match = True
    for fname, meta in checksums.items():
        fpath = PHASE1_DIR / fname
        if not fpath.exists():
            print(f"[FAIL] Artifact {fname} missing from {PHASE1_DIR}")
            all_checksums_match = False
            continue
        actual_h = sha256_file(fpath)
        actual_size = fpath.stat().st_size
        if actual_h != meta["sha256"] or actual_size != meta["size_bytes"]:
            print(f"[FAIL] Checksum/size mismatch on {fname}")
            all_checksums_match = False
        else:
            print(f"[PASS] {fname} ({actual_size:,} bytes) matches SHA-256")

    if not all_checksums_match:
        return False

    # 2. Recompute metrics from raw attempts in summary
    summary_path = PHASE1_DIR / "invariant_optimization_summary.json"
    with open(summary_path, "r", encoding="utf-8") as f:
        summary_data = json.load(f)

    arms = summary_data.get("systems_benchmark", {})
    full_tokens = sum(r["total_tokens_consumed"] for r in arms["full"]["records"])

    print("\n[*] Recomputing Arm Metrics Directly from Raw Attempt Traces:")
    recalc_passed = True
    expected_arms = ["full", "ci_k0", "ci_k1_static", "ci_k1_reactive", "ci_k2_reactive", "oracle_reactive"]
    for arm_name in expected_arms:
        arm_val = arms.get(arm_name)
        if not arm_val:
            print(f"[FAIL] Missing arm: {arm_name}")
            recalc_passed = False
            continue

        records = arm_val["records"]
        if len(records) != 32:
            print(f"[FAIL] Arm {arm_name} has {len(records)} tasks, expected 32")
            recalc_passed = False

        # Attempt level math validation
        for rec in records:
            att_token_sum = 0
            for a in rec["attempts"]:
                calc_tok = a["prompt_tokens"] + a["schema_tokens"] + a["completion_tokens"]
                if a["tokens"] != calc_tok:
                    print(f"[FAIL] Attempt token mismatch in {rec['task_id']} att {a['attempt']}: {a['tokens']} != {calc_tok}")
                    recalc_passed = False
                att_token_sum += a["tokens"]
            if rec["total_tokens_consumed"] != att_token_sum:
                print(f"[FAIL] Record total mismatch in {rec['task_id']}: {rec['total_tokens_consumed']} != {att_token_sum}")
                recalc_passed = False

        # Workload sum
        workload_tokens = sum(r["total_tokens_consumed"] for r in records)
        savings = round(((full_tokens - workload_tokens) / full_tokens) * 100.0, 2)
        fin_struct = round(sum(1 for r in records if r["final_structural_success"]) / len(records) * 100.0, 1)
        fin_sem = round(sum(1 for r in records if r["final_semantic_correctness"]) / len(records) * 100.0, 1)

        print(f"    - {arm_name:<16}: Workload Toks={workload_tokens:<7} | Savings={savings:>6.2f}% | FinalStruct={fin_struct:>5.1f}% | FinalSem={fin_sem:>5.1f}%")

    # 3. Cache payload audit
    cache_zip_path = PHASE1_DIR / "live_rerun_cache_entries.zip"
    print(f"\n[*] Auditing Live Response Payloads in {cache_zip_path.name}:")
    with zipfile.ZipFile(cache_zip_path, "r") as cz:
        names = cz.namelist()
        print(f"    - Total cached entries: {len(names)}")
        if len(names) != manifest["cache_entries_count"]:
            print(f"[FAIL] Cache file count mismatch: {len(names)} != {manifest['cache_entries_count']}")
            return False
        
        valid_rids = 0
        non_zero_lat = 0
        for n in names:
            cdata = json.loads(cz.read(n).decode("utf-8"))
            if cdata.get("resp_id"):
                valid_rids += 1
            if cdata.get("lat", 0) > 0:
                non_zero_lat += 1

        print(f"    - Verified valid Gemini response IDs: {valid_rids}/{len(names)}")
        print(f"    - Verified positive latency records:   {non_zero_lat}/{len(names)}")
        if valid_rids != len(names) or non_zero_lat != len(names):
            print("[FAIL] Some cache records have missing response IDs or zero latency")
            return False

    print("\n" + "=" * 80)
    print("ALL PHASE 1 LIVE ARTIFACT AUDITS PASSED CLEANLY (PASS)")
    print("=" * 80)
    return recalc_passed

if __name__ == "__main__":
    if not verify_phase1_artifacts():
        sys.exit(1)
