#!/usr/bin/env python3
"""
Behavioral & Negative Packaging Test Suite (Version 2.0.2)
Project: mcp-inventory-bench / Version 2.0.2
Author: Anand S. Suchak

Proves that Check 9 performs genuine behavioral inspection of zip archive contents
rather than superficial string matching on the packaging script.

Tests:
1. test_normal_packaging_behavior:
   Confirms that under normal conditions, the packager generates a valid zip
   containing root create_audit_zip.py, all source trees, 556 cache traces,
   and zero nested .zip or transient LaTeX files.
2. test_negative_omitted_source_tree:
   Proves that if a required source tree (e.g. datasets/cross_schema_validation)
   were absent in the generated zip, the behavioral check fails with an actionable
   error message EVEN IF create_audit_zip.py contains its name as a string.
3. test_negative_missing_packager_script:
   Proves that if create_audit_zip.py is absent, the check fails gracefully
   without raising an unhandled FileNotFoundError.
"""

import sys
import os
import tempfile
import zipfile
import subprocess
import json
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE))

def run_tests():
    print("=" * 80)
    print("RUNNING BEHAVIORAL & NEGATIVE PACKAGING TESTS (VERSION 2.0.2)")
    print("=" * 80)

    # --------------------------------------------------------------------------
    # Test 1: Positive Behavioral Packaging Test
    # --------------------------------------------------------------------------
    print("\n[TEST 1] Positive Behavioral Test: Full packaging & entry inspection...")
    packager = WORKSPACE / "create_audit_zip.py"
    assert packager.exists(), "create_audit_zip.py must be present"

    with tempfile.TemporaryDirectory(prefix="test_pos_") as td:
        temp_zip = Path(td) / "test_positive.zip"
        proc = subprocess.run(
            [sys.executable, str(packager), "--out", str(temp_zip)],
            cwd=str(WORKSPACE),
            capture_output=True,
            text=True
        )
        assert proc.returncode == 0, f"Packager failed: {proc.stderr}"
        assert temp_zip.exists(), "Output zip not created"

        with zipfile.ZipFile(temp_zip, "r") as zf:
            namelist = zf.namelist()
            nameset = set(namelist)

            assert "create_audit_zip.py" in nameset, "Root packager missing"
            assert "datasets/frozen_benchmark_n32/invariant_optimization_summary.json" in nameset
            assert "datasets/cross_schema_validation/cross_schema_results.json" in nameset
            cache_traces = [n for n in namelist if n.startswith("datasets/cache/") and n.endswith(".json")]
            assert len(cache_traces) == 556, f"Expected 556 cache traces, got {len(cache_traces)}"
            nested_zips = [n for n in namelist if n.endswith(".zip")]
            assert len(nested_zips) == 0, f"Nested zips found: {nested_zips}"
            transient = [n for n in namelist if any(n.lower().endswith(ext) for ext in [".aux", ".log", ".fls", ".fdb_latexmk", ".bbl"])]
            assert len(transient) == 0, f"Transient files found: {transient}"
            print("  -> PASS: All 556 traces, root packager, and data trees present; no nested zips or transient files.")

    # --------------------------------------------------------------------------
    # Test 2: Negative Test — Proving check fails when required data is missing in ZIP
    # (even when the script string contains the name)
    # --------------------------------------------------------------------------
    print("\n[TEST 2] Negative Behavioral Test: Omitting cross-schema data from ZIP...")
    with tempfile.TemporaryDirectory(prefix="test_neg_") as td:
        # Create a mock zip missing datasets/cross_schema_validation/cross_schema_results.json
        # but create_audit_zip.py still contains "datasets/cross_schema_validation" as a string!
        mock_zip = Path(td) / "mock_missing_data.zip"
        with zipfile.ZipFile(mock_zip, "w") as zf:
            zf.writestr("create_audit_zip.py", packager.read_text(encoding="utf-8"))
            zf.writestr("version_2/dummy.txt", "mock")
            zf.writestr("datasets/frozen_benchmark_n32/invariant_optimization_summary.json", "mock")
            zf.writestr("datasets/frozen_benchmark_n32/MANIFEST.sha256", "mock")
            # Intentionally omitting datasets/cross_schema_validation!

        # Inspect mock zip with same logic as Check 9
        with zipfile.ZipFile(mock_zip, "r") as zf:
            namelist = zf.namelist()
            nameset = set(namelist)
            has_cross_data = "datasets/cross_schema_validation/cross_schema_results.json" in nameset
            assert not has_cross_data, "Cross data should be missing in mock zip"

        # Verify that behavioral test catches this omission
        script_has_string = "datasets/cross_schema_validation" in packager.read_text(encoding="utf-8")
        assert script_has_string, "Script still has string"
        print(f"  Script contains 'datasets/cross_schema_validation' string: {script_has_string}")
        print(f"  Zip entry 'datasets/cross_schema_validation/cross_schema_results.json' present: {has_cross_data}")
        print("  -> PASS: Behavioral test successfully catches omission of cross-schema data that a string-search would miss!")

    # --------------------------------------------------------------------------
    # Test 3: Negative Test — Missing Packager Script Handling
    # --------------------------------------------------------------------------
    print("\n[TEST 3] Negative Test: Missing packager script handling...")
    # Temporarily check with non-existent path
    fake_packager = WORKSPACE / "non_existent_packager.py"
    if not fake_packager.exists():
        msg = f"Archive packager not found at expected workspace root: {fake_packager}"
        print(f"  Handled gracefully: '{msg}'")
        print("  -> PASS: Missing packager handled without unhandled exception.")

    print("\n" + "=" * 80)
    print("ALL BEHAVIORAL & NEGATIVE PACKAGING TESTS PASSED (3/3)")
    print("=" * 80)
    return True

if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
