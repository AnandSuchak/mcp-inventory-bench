#!/usr/bin/env python3
r"""
Comprehensive Audit & Integrity Verification Suite (Version 2.0.2)
Project: mcp-inventory-bench / Version 2.0.2
Author: Anand S. Suchak

Performs deep, independent programmatic recomputation across all Version 2 research artifacts:
1. Cryptographic Provenance: Direct parser and validator for MANIFEST.sha256 files + trusted pinned hashes
2. Raw Attempt-by-Attempt Token Accounting & Dual-Metric Savings Recomputation
3. Empirical Request Latency directly recomputed by parsing all 556 files in datasets/cache/
4. Retrieval Baselines directly recomputed from full_schema.json & benchmark_tasks_n32.json:
   - Lexical TF-IDF Macro Recall@2 (12.50%) & Zero-Recall count (24/32 = 75.0%)
   - Inductive Latent Semantic Analysis SVD-16 Macro Recall@2 (14.06%) & Zero-Recall count (23/32 = 71.88%)
5. LangGraph Counterfactual Token Model (+45 tok compiler context, 103,895 tokens, -7.52% net savings)
6. Formal Mathematical Theorem & Counterexample Consistency (K <= M - |A0|, IEEEproof, Sibling Leaf counterexample)
7. Manuscript Source & Table Layout Integrity (Table V column resize, Table IV pooled row dashes, NOT MEASURED retrieval rows)
8. Manuscript Formatting Invariants (\small removed from equation mode, wrapped long SHA-256, Table I resizebox)
9. Behavioral Audit Archive Packaging Verification: executes packaging to temporary output and verifies entries, counts (556 traces), and exclusion of nested zips / transient build files.

Outputs full audit results to stdout and saves version_2/verification_audit_certificate.json.
"""

import sys
import os
import json
import glob
import re
import math
import hashlib
import statistics
import argparse
import tempfile
import zipfile
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Set, Tuple
from collections import Counter

WORKSPACE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(WORKSPACE))

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
import numpy as np

from version_2.lasr_trace_audit import schema_chunks, tfidf_vectors, cosine_sparse

PINNED_FROZEN_HASH = "78c2c88ed5128e0f296fa29e0c258589b516f3adb14b0b8da491fa73bc3ffc11"
PINNED_CROSS_HASH = "b3d57636f9834ff536204acfe88454c9620228bb67705f1b3caa40e0d562302a"

def compute_sha256(filepath: Path) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def percentile(vals: List[float], p: float) -> float:
    if not vals:
        return 0.0
    sorted_vals = sorted(vals)
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    pos = (len(sorted_vals) - 1) * p
    lo, hi = math.floor(pos), math.ceil(pos)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (pos - lo)

def parse_and_validate_manifest(manifest_path: Path) -> Tuple[bool, str, Dict[str, str]]:
    """Directly parse MANIFEST.sha256 file and verify all entries against disk files."""
    if not manifest_path.exists():
        return False, f"Manifest file missing: {manifest_path}", {}

    entries: Dict[str, str] = {}
    try:
        content = manifest_path.read_text(encoding="utf-8")
        for line_num, line in enumerate(content.splitlines(), start=1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            parts = line.split(None, 1)
            if len(parts) != 2:
                return False, f"Malformed entry at line {line_num} in {manifest_path.name}: '{line}'", {}

            expected_hash, filename = parts[0].strip(), parts[1].strip()
            if len(expected_hash) != 64 or not all(c in "0123456789abcdefABCDEF" for c in expected_hash):
                return False, f"Malformed SHA-256 hash at line {line_num} in {manifest_path.name}: '{expected_hash}'", {}

            target_file = manifest_path.parent / filename
            if not target_file.exists():
                return False, f"File listed in {manifest_path.name} not found on disk: {target_file}", {}

            actual_hash = compute_sha256(target_file)
            if actual_hash.lower() != expected_hash.lower():
                return False, f"Hash mismatch for {filename} in {manifest_path.name}: expected {expected_hash}, got {actual_hash}", {}

            entries[filename] = actual_hash
    except Exception as exc:
        return False, f"Error reading manifest {manifest_path}: {exc}", {}

    if not entries:
        return False, f"Manifest {manifest_path.name} contained zero valid entries", {}

    return True, f"Verified {len(entries)} file entries against disk", entries

def verify_all(audit_stage: str = "pre_packaging_audit") -> bool:
    checks = []
    runtime_timestamp = datetime.now(timezone.utc).astimezone().isoformat()
    
    print("=" * 80)
    print("LASR-MCP VERSION 2.0.2: DEEP INTEGRITY & BEHAVIORAL VERIFICATION AUDIT")
    print(f"Audit Stage: {audit_stage}")
    print(f"Timestamp:   {runtime_timestamp}")
    print("=" * 80)

    # --------------------------------------------------------------------------
    # Check 1: Cryptographic Provenance & Direct Manifest Validation
    # --------------------------------------------------------------------------
    frozen_manifest = WORKSPACE / "datasets" / "frozen_benchmark_n32" / "MANIFEST.sha256"
    cross_manifest = WORKSPACE / "datasets" / "cross_schema_validation" / "MANIFEST.sha256"

    frozen_m_ok, frozen_m_msg, frozen_entries = parse_and_validate_manifest(frozen_manifest)
    cross_m_ok, cross_m_msg, cross_entries = parse_and_validate_manifest(cross_manifest)

    # Independent trusted pinned hash validation
    frozen_file = WORKSPACE / "datasets" / "frozen_benchmark_n32" / "invariant_optimization_summary.json"
    cross_file = WORKSPACE / "datasets" / "cross_schema_validation" / "cross_schema_results.json"

    act_frozen_hash = compute_sha256(frozen_file) if frozen_file.exists() else ""
    act_cross_hash = compute_sha256(cross_file) if cross_file.exists() else ""

    trusted_frozen_ok = (act_frozen_hash == PINNED_FROZEN_HASH)
    trusted_cross_ok = (act_cross_hash == PINNED_CROSS_HASH)

    # Cross-schema records count validation
    cross_recs_count = 0
    if cross_file.exists():
        try:
            with open(cross_file, "r", encoding="utf-8") as f:
                cross_data = json.load(f)
            cross_recs_count = len(cross_data.get("records", []))
        except Exception:
            pass
    cross_recs_ok = (cross_recs_count == 64)

    c1_passed = (frozen_m_ok and cross_m_ok and 
                 trusted_frozen_ok and trusted_cross_ok and 
                 cross_recs_ok)

    details_c1 = (f"Frozen Manifest={frozen_m_ok} ({frozen_m_msg}), "
                  f"Cross Manifest={cross_m_ok} ({cross_m_msg}), "
                  f"Trusted Frozen Pinned Hash Match={trusted_frozen_ok}, "
                  f"Trusted Cross Pinned Hash Match={trusted_cross_ok}, "
                  f"Cross Records={cross_recs_count} (exp 64)")

    checks.append({
        "check": "Cryptographic Manifest Validation & Trusted Pinned Hashes",
        "passed": c1_passed,
        "details": details_c1
    })
    print(f"[{'PASS' if c1_passed else 'FAIL'}] 1. Cryptographic Provenance: Manifests parsed and verified against disk files; pinned hashes matched.")

    # --------------------------------------------------------------------------
    # Check 2: Raw Attempt-by-Attempt Token Accounting Recomputation
    # --------------------------------------------------------------------------
    if not frozen_file.exists():
        checks.append({
            "check": "Raw Attempt Token Sums & Structural Success Recomputation",
            "passed": False,
            "details": f"FAIL: Frozen benchmark file missing at {frozen_file}"
        })
        print(f"[FAIL] 2. Raw Token Recomputation: Missing {frozen_file}")
        full_recs, k2_recs, k1_recs = [], [], []
        full_sum, k2_sum, k1_sum = 0, 0, 0
    else:
        with open(frozen_file, "r", encoding="utf-8") as f:
            frozen_data = json.load(f)
        
        sb = frozen_data.get("systems_benchmark", {})
        full_recs = sb.get("full", {}).get("records", [])
        k2_recs = sb.get("ci_k2_reactive", {}).get("records", [])
        k1_recs = sb.get("ci_k1_reactive", {}).get("records", [])

        full_sum = sum(sum(a["tokens"] for a in r["attempts"]) for r in full_recs)
        k2_sum = sum(sum(a["tokens"] for a in r["attempts"]) for r in k2_recs)
        k1_sum = sum(sum(a["tokens"] for a in r["attempts"]) for r in k1_recs)

        full_successes = sum(1 for r in full_recs if r["final_structural_success"])
        k2_successes = sum(1 for r in k2_recs if r["final_structural_success"])
        k1_successes = sum(1 for r in k1_recs if r["final_structural_success"])

        c2_passed = (full_sum == 96629 and k2_sum == 75248 and k1_sum == 77140 and
                     full_successes == 30 and k2_successes == 32 and k1_successes == 32)
        checks.append({
            "check": "Raw Attempt Token Sums & Structural Success Recomputation",
            "passed": c2_passed,
            "details": f"Full={full_sum} tok ({full_successes}/32 succ), k2={k2_sum} tok ({k2_successes}/32 succ), k1={k1_sum} tok ({k1_successes}/32 succ)"
        })
        print(f"[{'PASS' if c2_passed else 'FAIL'}] 2. Raw Token Recomputation: Full={full_sum} (30/32), k2={k2_sum} (32/32), k1={k1_sum} (32/32)")

    # --------------------------------------------------------------------------
    # Check 3: Dual-Metric Token Savings Reconciliation (Workload vs. Conditional TTS)
    # --------------------------------------------------------------------------
    if not full_recs or not k2_recs or full_sum == 0:
        checks.append({
            "check": "Dual Metric Token Reconciliation (Workload vs. Conditional TTS)",
            "passed": False,
            "details": "FAIL: Benchmark records unavailable for dual-metric calculation"
        })
        print("[FAIL] 3. Dual Token Metrics: Benchmark records unavailable")
    else:
        workload_savings_k2 = ((full_sum - k2_sum) / full_sum) * 100.0 # 22.126% -> 22.1%
        workload_savings_k1 = ((full_sum - k1_sum) / full_sum) * 100.0 # 20.168% -> 20.2%
        
        # Conditional TTS calculation strictly over successful tasks
        full_tts_vals = [r["total_tokens_consumed"] for r in full_recs if r["final_structural_success"]]
        k2_tts_vals = [r["total_tokens_consumed"] for r in k2_recs if r["final_structural_success"]]
        
        full_mean_tts = statistics.mean(full_tts_vals)
        k2_mean_tts = statistics.mean(k2_tts_vals)
        tts_savings = ((full_mean_tts - k2_mean_tts) / full_mean_tts) * 100.0 # 19.28% -> 19.3%

        tts_ok = (abs(full_mean_tts - 2913.2) < 0.1 and abs(k2_mean_tts - 2351.5) < 0.1)
        savings_ok = (abs(workload_savings_k2 - 22.1) < 0.1 and abs(tts_savings - 19.3) < 0.1)

        c3_passed = tts_ok and savings_ok
        checks.append({
            "check": "Dual Metric Token Reconciliation (Workload vs. Conditional TTS)",
            "passed": c3_passed,
            "details": f"Workload Savings={workload_savings_k2:.2f}% (exp 22.1%), Conditional TTS Savings={tts_savings:.2f}% (exp 19.3%), Full TTS Mean={full_mean_tts:.1f}, k2 TTS Mean={k2_mean_tts:.1f}"
        })
        print(f"[{'PASS' if c3_passed else 'FAIL'}] 3. Dual Token Metrics: Workload Savings={workload_savings_k2:.2f}%, TTS Savings={tts_savings:.2f}%")

    # --------------------------------------------------------------------------
    # Check 4: Empirical Latency Recomputed from 556 Provider Execution Traces
    # --------------------------------------------------------------------------
    cache_files = glob.glob(str(WORKSPACE / "datasets" / "cache" / "*.json"))
    raw_latencies_ms = []
    for fpath in cache_files:
        try:
            with open(fpath, "r", encoding="utf-8") as fp:
                d = json.load(fp)
                if "lat" in d and isinstance(d["lat"], (int, float)):
                    raw_latencies_ms.append(float(d["lat"]))
        except Exception:
            pass

    csv_lat_file = WORKSPACE / "version_2" / "latency_benchmark_measurements.csv"
    ast_latencies_ms = []
    if csv_lat_file.exists():
        with open(csv_lat_file, "r", encoding="utf-8") as fp:
            for line in fp:
                parts = line.strip().split(",")
                if len(parts) >= 9 and parts[0].isdigit():
                    ast_latencies_ms.append(float(parts[8]))

    if len(raw_latencies_ms) != 556 or len(ast_latencies_ms) != 1000:
        c4_passed = False
        details = f"FAIL: Expected 556 cache traces (got {len(raw_latencies_ms)}) and 1000 AST runs (got {len(ast_latencies_ms)})"
    else:
        req_p50 = percentile(raw_latencies_ms, 0.50)
        req_p90 = percentile(raw_latencies_ms, 0.90)
        req_p99 = percentile(raw_latencies_ms, 0.99)
        ast_p50 = percentile(ast_latencies_ms, 0.50)
        ast_p99 = percentile(ast_latencies_ms, 0.99)
        overhead_ratio = (ast_p50 / req_p50) * 100.0

        c4_passed = (abs(req_p50 - 3407.1) < 2.0 and abs(req_p99 - 56708.5) < 2.0 and
                     abs(ast_p50 - 0.0201) < 0.005 and overhead_ratio < 0.001)
        details = (f"556 Cache traces: p50={req_p50:.1f}ms, p90={req_p90:.1f}ms, p99={req_p99:.1f}ms. "
                   f"1000 AST runs: p50={ast_p50*1000:.1f}us ({ast_p50:.4f}ms), Ratio={overhead_ratio:.5f}%")

    checks.append({
        "check": "Empirical Latency Hierarchy & AST Overhead Recomputation",
        "passed": c4_passed,
        "details": details
    })
    print(f"[{'PASS' if c4_passed else 'FAIL'}] 4. Empirical Latency: 556 Cache Traces p50={req_p50:.1f}ms, 1000 AST Runs p50={ast_p50*1000:.1f}us, AST Ratio={overhead_ratio:.5f}% (<0.001%)")

    # --------------------------------------------------------------------------
    # Check 5: Direct Recomputation of Retrieval Baselines (TF-IDF & Inductive LSA)
    # --------------------------------------------------------------------------
    schema_file = WORKSPACE / "version_2" / "full_schema.json"
    tasks_file = WORKSPACE / "version_2" / "benchmark_tasks_n32.json"

    if not schema_file.exists() or not tasks_file.exists():
        c5_passed = False
        details = f"FAIL: Missing schema ({schema_file.exists()}) or tasks ({tasks_file.exists()})"
    else:
        with open(schema_file, "r", encoding="utf-8") as f:
            full_schema_obj = json.load(f)
        with open(tasks_file, "r", encoding="utf-8") as f:
            tasks_obj = json.load(f)

        chunks = schema_chunks(full_schema_obj)
        chunk_texts = [f"{c['id']} {c['text']}" for c in chunks]
        task_queries = [t["query"] for t in tasks_obj]

        # A. Recompute Lexical TF-IDF Baseline
        corpus = [c["text"] for c in chunks] + task_queries
        lex_vecs = tfidf_vectors(corpus)
        chunk_lex_vecs = lex_vecs[:len(chunks)]
        task_lex_vecs = lex_vecs[len(chunks):]
        lex_recalls = []
        lex_zero_hits = 0
        for task, qvec in zip(tasks_obj, task_lex_vecs):
            ranked_idx = sorted(range(len(chunks)), key=lambda i: cosine_sparse(qvec, chunk_lex_vecs[i]), reverse=True)[:2]
            retrieved = {chunks[i]["id"] for i in ranked_idx}
            gold = set(task["target_constraints"])
            found = gold & retrieved
            rec = len(found) / len(gold) if gold else 0.0
            lex_recalls.append(rec)
            if len(found) == 0:
                lex_zero_hits += 1
        recomputed_lex_recall = statistics.mean(lex_recalls)

        # B. Recompute Inductive LSA SVD Baseline
        tfidf_ind = TfidfVectorizer(ngram_range=(1, 3), sublinear_tf=True, min_df=1)
        chunk_tfidf = tfidf_ind.fit_transform(chunk_texts)
        task_tfidf = tfidf_ind.transform(task_queries)

        n_comp = min(16, chunk_tfidf.shape[1] - 1)
        svd = TruncatedSVD(n_components=n_comp, random_state=42)
        chunk_emb = svd.fit_transform(chunk_tfidf)
        task_emb = svd.transform(task_tfidf)

        def cos_sim(v1, v2):
            n1, n2 = np.linalg.norm(v1), np.linalg.norm(v2)
            return float(np.dot(v1, v2) / (n1 * n2)) if (n1 > 0 and n2 > 0) else 0.0

        lsa_recalls = []
        lsa_zero_hits = 0
        for task, q_vec in zip(tasks_obj, task_emb):
            sims = [cos_sim(q_vec, c_vec) for c_vec in chunk_emb]
            ranked_idx = sorted(range(len(chunks)), key=lambda i: sims[i], reverse=True)[:2]
            retrieved = {chunks[i]["id"] for i in ranked_idx}
            gold = set(task["target_constraints"])
            found = gold & retrieved
            rec = len(found) / len(gold) if gold else 0.0
            lsa_recalls.append(rec)
            if len(found) == 0:
                lsa_zero_hits += 1
        recomputed_lsa_recall = statistics.mean(lsa_recalls)

        c5_passed = (abs(recomputed_lex_recall - 0.1250) < 0.001 and
                     lex_zero_hits == 24 and
                     abs(recomputed_lsa_recall - 0.1406) < 0.001 and
                     lsa_zero_hits == 23)
        details = (f"TF-IDF Recall@2={recomputed_lex_recall*100:.2f}% (zero-hits: {lex_zero_hits}/32 = {lex_zero_hits/32*100:.1f}%), "
                   f"LSA SVD Recall@2={recomputed_lsa_recall*100:.2f}% (zero-hits: {lsa_zero_hits}/32 = {lsa_zero_hits/32*100:.1f}%)")

    checks.append({
        "check": "Retrieval Baselines Direct Programmatic Recomputation",
        "passed": c5_passed,
        "details": details
    })
    print(f"[{'PASS' if c5_passed else 'FAIL'}] 5. Retrieval Baselines Recomputed: TF-IDF={recomputed_lex_recall*100:.1f}% ({lex_zero_hits}/32 zero-hits), LSA SVD={recomputed_lsa_recall*100:.1f}% ({lsa_zero_hits}/32 zero-hits)")

    # --------------------------------------------------------------------------
    # Check 6: LangGraph Counterfactual Model Audit
    # --------------------------------------------------------------------------
    lg_path = WORKSPACE / "version_2" / "langgraph_traces.json"
    if not lg_path.exists():
        c6_passed = False
        details = f"FAIL: LangGraph trace file missing at {lg_path}"
    else:
        with open(lg_path, "r", encoding="utf-8") as f:
            lg_data = json.load(f)
        act_lg_tokens = lg_data.get("total_workload_tokens", 0)

        lg_overhead = ((act_lg_tokens - full_sum) / full_sum) * 100.0 if full_sum else 0.0
        lg_lasr_savings = ((act_lg_tokens - k2_sum) / act_lg_tokens) * 100.0 if act_lg_tokens else 0.0

        c6_passed = (act_lg_tokens == 103895 and
                     abs(lg_overhead - 7.52) < 0.05 and
                     abs(lg_lasr_savings - 27.57) < 0.05)
        details = f"LangGraph Total={act_lg_tokens} tok (+{lg_overhead:.2f}% overhead vs Full -> -{lg_overhead:.2f}% savings; LASR k=2 vs LangGraph savings={lg_lasr_savings:.2f}%)"

    checks.append({
        "check": "LangGraph Counterfactual Model Token Overhead Audit",
        "passed": c6_passed,
        "details": details
    })
    print(f"[{'PASS' if c6_passed else 'FAIL'}] 6. LangGraph Model Audit: Total={act_lg_tokens} tok, Overhead=+{lg_overhead:.2f}% (-{lg_overhead:.2f}% net savings), LASR k=2 Savings={lg_lasr_savings:.2f}%")

    # --------------------------------------------------------------------------
    # Check 7: Formal Mathematical Theorem & Counterexample Integrity
    # --------------------------------------------------------------------------
    paper_sec2 = WORKSPACE / "version_2" / "paper_v2" / "sections" / "02_system_architecture.tex"
    proof_standalone = WORKSPACE / "version_2" / "formal_termination_proof.tex"
    
    if not paper_sec2.exists() or not proof_standalone.exists():
        c7_passed = False
        details = f"FAIL: Missing paper section 2 ({paper_sec2.exists()}) or standalone proof ({proof_standalone.exists()})"
    else:
        sec2_text = paper_sec2.read_text(encoding="utf-8")
        proof_text = proof_standalone.read_text(encoding="utf-8")

        has_cardinality = ("K \\le M - |A_0|" in sec2_text and "K \\le M - |A_0|" in proof_text)
        has_ieee_proof = ("\\begin{IEEEproof}" in sec2_text and "\\end{IEEEproof}" in sec2_text)
        has_counterexample = ("sibling leaf constraint" in sec2_text.lower() or "two sibling leaf" in sec2_text.lower() or "two independent constraints" in sec2_text.lower())
        rejects_depth = ("invalid" in sec2_text.lower() or "does not constrain" in sec2_text.lower())

        c7_passed = has_cardinality and has_ieee_proof and has_counterexample and rejects_depth
        details = f"Bound=K<=M-|A0| ({has_cardinality}), IEEEproof Environment ({has_ieee_proof}), Sibling Leaf Counterexample ({has_counterexample}), K<=D Rejected ({rejects_depth})"

    checks.append({
        "check": "Formal Mathematical Theorem & Counterexample Consistency",
        "passed": c7_passed,
        "details": details
    })
    print(f"[{'PASS' if c7_passed else 'FAIL'}] 7. Formal Proof: K<=M-|A0| Established with IEEEproof and Sibling Leaf Counterexample")

    # --------------------------------------------------------------------------
    # Check 8: Manuscript Source Layout & Formatting Warnings Integrity
    # --------------------------------------------------------------------------
    table1_path = WORKSPACE / "version_2" / "paper_v2" / "tables" / "table1_systems_evaluation.tex"
    table4_path = WORKSPACE / "version_2" / "paper_v2" / "tables" / "table4_cross_schema.tex"
    setup_path = WORKSPACE / "version_2" / "paper_v2" / "sections" / "03_experimental_setup.tex"
    results_path = WORKSPACE / "version_2" / "paper_v2" / "sections" / "04_results.tex"
    csv_table5 = WORKSPACE / "version_2" / "baseline_comparison_table.csv"

    if not table4_path.exists() or not results_path.exists() or not csv_table5.exists() or not setup_path.exists() or not table1_path.exists():
        c8_passed = False
        details = f"FAIL: Missing manuscript table or section files"
    else:
        table1_text = table1_path.read_text(encoding="utf-8")
        table4_text = table4_path.read_text(encoding="utf-8")
        setup_text = setup_path.read_text(encoding="utf-8")
        results_text = results_path.read_text(encoding="utf-8")
        csv_text = csv_table5.read_text(encoding="utf-8")

        # Formatting checks
        t1_resized = ("\\resizebox{\\textwidth}{!}" in table1_text)
        no_small_in_math = ("\\small\nC_R^{(t+1)}" not in sec2_text and "\\small\r\nC_R^{(t+1)}" not in sec2_text)
        sha_wrapped = ("\\phantom{SHA-256: }" in setup_text or "b516f3adb14b0b8da491fa73bc3ffc11" in setup_text)
        
        pooled_dashes = ("Pooled Workload Aggregate" in table4_text and "-- & --" in table4_text)
        table5_resize = ("\\resizebox{\\columnwidth}{!}" in results_text)
        reports_12_5 = ("12.5\\%" in results_text or "12.5%" in results_text)
        reports_14_1 = ("14.1\\%" in results_text or "14.1%" in results_text)
        reports_zero_hits = ("75.0\\%" in results_text and "71.9\\%" in results_text)
        sublinear_lsa = ("sublinear word 1-to-3-grams" in results_text)
        csv_retrieval_separated = ("NOT MEASURED (Retrieval-Only)" in csv_text)
        csv_counterfactual_labeled = ("Counterfactual Token Model" in csv_text or "Counterfactual Token-History Model" in csv_text)
        csv_sign_convention = ("-7.5% (Token Overhead)" in csv_text)

        c8_passed = (t1_resized and no_small_in_math and sha_wrapped and pooled_dashes and
                     table5_resize and reports_12_5 and reports_14_1 and
                     reports_zero_hits and sublinear_lsa and csv_retrieval_separated and
                     csv_counterfactual_labeled and csv_sign_convention)
        details = (f"Table 1 resizebox={t1_resized}, Math \\small removed={no_small_in_math}, "
                   f"SHA-256 line wrapped={sha_wrapped}, Table 4 dashes={pooled_dashes}, "
                   f"Table 5 resizebox={table5_resize}, Exact recall={reports_12_5 and reports_14_1}, "
                   f"Zero-hits={reports_zero_hits}, CSV separated={csv_retrieval_separated}")

    checks.append({
        "check": "Manuscript Source Layout & Formatting Warnings Integrity",
        "passed": c8_passed,
        "details": details
    })
    print(f"[{'PASS' if c8_passed else 'FAIL'}] 8. Manuscript Integrity: Math \\small removed, SHA-256 wrapped, Tables resized, CSV separated.")

    # --------------------------------------------------------------------------
    # Check 9: Behavioral Audit Archive Packaging & Structure Verification
    # --------------------------------------------------------------------------
    packager_script = WORKSPACE / "create_audit_zip.py"
    if not packager_script.exists():
        c9_passed = False
        details_c9 = (f"FAIL: Archive packager not found at expected workspace root: {packager_script}. "
                      "create_audit_zip.py must be present at workspace root.")
    else:
        temp_dir = None
        try:
            temp_dir = tempfile.TemporaryDirectory(prefix="lasr_audit_test_")
            temp_zip_path = Path(temp_dir.name) / "test_behavioral_audit.zip"

            # Execute the actual packaging script into a controlled temp location
            proc = subprocess.run(
                [sys.executable, str(packager_script), "--out", str(temp_zip_path)],
                cwd=str(WORKSPACE),
                capture_output=True,
                text=True,
                timeout=120
            )

            if proc.returncode != 0:
                c9_passed = False
                details_c9 = f"FAIL: Packager execution failed (exit code {proc.returncode}): {proc.stderr.strip()}"
            elif not temp_zip_path.exists():
                c9_passed = False
                details_c9 = f"FAIL: Packager did not generate output archive at {temp_zip_path}"
            else:
                with zipfile.ZipFile(temp_zip_path, "r") as zf:
                    namelist = zf.namelist()
                    nameset = set(namelist)

                    has_root_packager = "create_audit_zip.py" in nameset
                    has_v2_tree = any(n.startswith("version_2/") for n in namelist)
                    has_frozen_data = "datasets/frozen_benchmark_n32/invariant_optimization_summary.json" in nameset
                    has_frozen_manifest = "datasets/frozen_benchmark_n32/MANIFEST.sha256" in nameset
                    has_cross_data = "datasets/cross_schema_validation/cross_schema_results.json" in nameset
                    has_cross_manifest = "datasets/cross_schema_validation/MANIFEST.sha256" in nameset
                    
                    cache_traces = [n for n in namelist if n.startswith("datasets/cache/") and n.endswith(".json")]
                    cache_count = len(cache_traces)
                    has_556_cache = (cache_count == 556)

                    has_trace_tree = any(n.startswith("trace/") for n in namelist)
                    nested_zips = [n for n in namelist if n.endswith(".zip")]
                    has_no_nested_zips = (len(nested_zips) == 0)

                    transient_latex = [n for n in namelist if any(n.lower().endswith(ext) for ext in [".aux", ".log", ".fls", ".fdb_latexmk", ".bbl", ".blg"])]
                    has_no_transient_latex = (len(transient_latex) == 0)

                    c9_passed = bool(has_root_packager and has_v2_tree and 
                                     has_frozen_data and has_frozen_manifest and
                                     has_cross_data and has_cross_manifest and
                                     has_556_cache and has_trace_tree and
                                     has_no_nested_zips and has_no_transient_latex)

                    details_c9 = (f"packager_root={has_root_packager}, v2_tree={has_v2_tree}, "
                                  f"frozen_data={has_frozen_data}, cross_data={has_cross_data}, "
                                  f"cache_traces_count={cache_count} (exp 556), trace_tree={has_trace_tree}, "
                                  f"nested_zips={len(nested_zips)}, transient_latex={len(transient_latex)}")
        except Exception as exc:
            c9_passed = False
            details_c9 = f"FAIL: Behavioral packaging test encountered exception: {exc}"
        finally:
            if temp_dir is not None:
                try:
                    temp_dir.cleanup()
                except Exception:
                    pass

    checks.append({
        "check": "Behavioral Audit Archive Packaging & Structure Verification",
        "passed": c9_passed,
        "details": details_c9
    })
    print(f"[{'PASS' if c9_passed else 'FAIL'}] 9. Behavioral Packaging: Packager executed, zip inspected, 556 cache traces confirmed, 0 nested zips.")

    # --------------------------------------------------------------------------
    # Summary & Certificate Export
    # --------------------------------------------------------------------------
    all_passed = all(c["passed"] for c in checks)
    cert = {
        "audit_name": "LASR-MCP Version 2 Scientific Integrity & Verification Certificate",
        "release_version": "2.0.2",
        "audit_stage": audit_stage,
        "status": "ALL_CHECKS_PASSED" if all_passed else "CHECKS_FAILED",
        "total_checks": len(checks),
        "passed_checks": sum(1 for c in checks if c["passed"]),
        "failed_checks": sum(1 for c in checks if not c["passed"]),
        "audit_timestamp": runtime_timestamp,
        "checks": checks
    }

    cert_path = WORKSPACE / "version_2" / "verification_audit_certificate.json"
    try:
        cert_path.parent.mkdir(parents=True, exist_ok=True)
        with open(cert_path, "w", encoding="utf-8") as f:
            json.dump(cert, f, indent=2)
    except Exception as exc:
        print(f"ERROR: Could not write certificate to {cert_path}: {exc}")

    print("=" * 80)
    if all_passed:
        print(f"ALL {len(checks)} VERIFICATION CHECKS PASSED SUCCESSFULLY.")
        print(f"Audit Certificate ({audit_stage}) saved to {cert_path.name}")
    else:
        print(f"AUDIT FAILED: {cert['failed_checks']} of {len(checks)} checks failed. Review logs above.")
        print(f"Failure Certificate saved to {cert_path.name}")
    print("=" * 80)
    return all_passed

def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--stage", default="pre_packaging_audit", help="Audit stage identifier (e.g. pre_packaging_audit, clean_extraction_verification)")
    args = parser.parse_args()
    success = verify_all(audit_stage=args.stage)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
