#!/usr/bin/env python3
"""
Bundle Creator for LASR-MCP Version 2.0.2 Audit Archive
Project: mcp-inventory-bench / Version 2.0.2
Author: Anand S. Suchak

Packages all Version 2 scripts, results, and raw provenance files into:
lasr_v2_audit_bundle_v2.0.2.zip (or specified --out path)

Included contents:
1. create_audit_zip.py (Self-packaging at workspace root for full audit reproducibility)
2. Complete version_2/ directory (scripts, raw benchmarks, tables, proofs, certificate)
3. datasets/cross_schema_validation/ (64 cross-schema records, MANIFEST.sha256)
4. datasets/frozen_benchmark_n32/ (raw frozen benchmark, MANIFEST.sha256, metadata.json)
5. datasets/cache/*.json (556 raw provider execution traces)
6. trace/ (all original trace processing, slicer, recomposer, runner implementations)
7. requirements.txt

Excludes:
- *.zip archives (preventing recursive self-inclusion)
- Transient LaTeX build artifacts: .aux, .log, .fls, .out, .fdb_latexmk, .bbl, .blg, .synctex.gz, .toc
- Python bytecode: __pycache__/, *.pyc, *.pyo
- VCS and virtual environments: .git/, .venv/, .pytest_cache/
- Temporary directories and test folders: tmp/, temp/, temp_*
"""

import os
import sys
import argparse
import zipfile
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parent

LATEX_TRANSIENT_EXTS = {
    ".aux", ".log", ".fls", ".out", ".fdb_latexmk",
    ".bbl", ".blg", ".synctex.gz", ".toc", ".lof", ".lot"
}

def make_audit_bundle(out_path: str = "lasr_v2_audit_bundle_v2.0.2.zip") -> Path:
    target = Path(out_path)
    zip_path = target if target.is_absolute() else (WORKSPACE / target)
    
    include_paths = [
        "create_audit_zip.py",
        "version_2",
        "datasets/frozen_benchmark_n32",
        "datasets/cross_schema_validation",
        "datasets/cache",
        "trace",
        "requirements.txt"
    ]

    print(f"Creating audit zip: {zip_path.name}...")
    file_count = 0
    total_bytes = 0

    # Ensure parent directory exists
    zip_path.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for item in include_paths:
            p = WORKSPACE / item
            if not p.exists():
                print(f"  WARNING: Path does not exist: {item}")
                continue

            if p.is_file():
                # Never include any zip archive or transient LaTeX file
                if p.suffix.lower() == ".zip" or p.suffix.lower() in LATEX_TRANSIENT_EXTS:
                    continue
                zf.write(p, arcname=item)
                file_count += 1
                total_bytes += p.stat().st_size
                print(f"  Added file: {item}")
            elif p.is_dir():
                for root, dirs, files in os.walk(p):
                    # Filter out cache, git, venv, and temporary directories
                    dirs[:] = [d for d in dirs if d not in (
                        "__pycache__", ".pytest_cache", ".git", ".venv", "tmp", "temp"
                    ) and not d.startswith("temp_") and not d.startswith("test_")]
                    
                    for f in files:
                        lower_f = f.lower()
                        # Exclude compiled bytecode, OS metadata, and any zip file
                        if lower_f.endswith((".pyc", ".pyo", ".zip")) or lower_f == ".ds_store":
                            continue
                        # Exclude LaTeX transient build artifacts
                        if any(lower_f.endswith(ext) for ext in LATEX_TRANSIENT_EXTS):
                            continue

                        full_f = Path(root) / f
                        # Prevent self-inclusion if zip is inside tree
                        if full_f.resolve() == zip_path.resolve():
                            continue

                        rel_name = full_f.relative_to(WORKSPACE).as_posix()
                        zf.write(full_f, arcname=rel_name)
                        file_count += 1
                        total_bytes += full_f.stat().st_size

    zip_size_mb = zip_path.stat().st_size / (1024 * 1024)
    raw_size_mb = total_bytes / (1024 * 1024)
    print("\nAudit Bundle Successfully Created!")
    print(f"Archive: {zip_path.name}")
    print(f"Location: {zip_path.resolve()}")
    print(f"Files Packaged: {file_count}")
    print(f"Raw Size: {raw_size_mb:.2f} MB")
    print(f"Compressed Size: {zip_size_mb:.2f} MB")
    return zip_path

def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", default="lasr_v2_audit_bundle_v2.0.2.zip", help="Output zip filename (default: lasr_v2_audit_bundle_v2.0.2.zip)")
    args = parser.parse_args()
    make_audit_bundle(args.out)

if __name__ == "__main__":
    main()
